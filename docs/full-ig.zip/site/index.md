# Home - DIPS Core Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://dips.no/fhir/R4/ImplementationGuide/dips.fhir.no.core | *Version*:0.1.0 |
| Draft as of 2026-11-10 | *Computable Name*:DIPSCore |

### DIPS Core Implementation Guide

This Implementation Guide describes the FHIR R4 profiles, extensions, value sets, code systems and examples used by DIPS AS to expose core clinical and administrative data — such as Patient, Person, Organization, Location, Practitioner, PractitionerRole, RelatedPerson, HealthcareService, Encounter and vital sign observations — through the DIPS FHIR R4 API.

The profiles in this guide build on [hl7.fhir.no.basis](https://simplifier.net/HL7Norway/), the Norwegian national base profiles, adding DIPS-specific extensions and constraints required to represent data from the DIPS core system.

##### Intended audience

This guide is intended for developers and integrators building or consuming integrations against the DIPS FHIR R4 API. See the [Documentation](documentation.md) page for details on authentication and how to call the API, [Artifacts](artifacts.md) for the full list of profiles, extensions, value sets and code systems, and [Download](download.md) for how to obtain the packaged IG.

##### Scope

* **Demographics**: Patient, Person, RelatedPerson
* **Organizational structure**: Organization, Location, HealthcareService
* **Practitioners**: Practitioner, PractitionerRole
* **Clinical**: Encounter, Appointment, DocumentReference, and Norwegian vital sign Observation profiles (blood pressure, body height/weight/temperature/mass index, heart rate, oxygen saturation, respiration rate, consciousness, NEWS2 and qSOFA scores, GCS)



## Resource Content

```json
{
  "resourceType" : "ImplementationGuide",
  "id" : "dips.fhir.no.core",
  "url" : "http://dips.no/fhir/R4/ImplementationGuide/dips.fhir.no.core",
  "version" : "0.1.0",
  "name" : "DIPSCore",
  "title" : "DIPS Core Implementation Guide",
  "status" : "draft",
  "date" : "2026-11-10T08:48:38+00:00",
  "publisher" : "DIPS AS",
  "contact" : [{
    "name" : "Lars-Andreas Nystad",
    "telecom" : [{
      "system" : "email",
      "value" : "mailto:lan@dips.no",
      "use" : "work"
    }]
  }],
  "description" : "Example Implementation Guide for getting started with SUSHI",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "NO",
      "display" : "Norway"
    }]
  }],
  "packageId" : "dips.fhir.no.core",
  "license" : "CC0-1.0",
  "fhirVersion" : ["4.0.1"],
  "dependsOn" : [{
    "id" : "hl7tx",
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
      "valueMarkdown" : "Automatically added as a dependency - all IGs depend on HL7 Terminology"
    }],
    "uri" : "http://terminology.hl7.org/ImplementationGuide/hl7.terminology",
    "packageId" : "hl7.terminology.r4",
    "version" : "7.5.0"
  },
  {
    "id" : "hl7ext",
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
      "valueMarkdown" : "Automatically added as a dependency - all IGs depend on the HL7 Extension Pack"
    }],
    "uri" : "http://hl7.org/fhir/extensions/ImplementationGuide/hl7.fhir.uv.extensions",
    "packageId" : "hl7.fhir.uv.extensions.r4",
    "version" : "5.4.0"
  },
  {
    "id" : "hl7_fhir_no_basis",
    "uri" : "http://fhir.org/packages/hl7.fhir.no.basis/ImplementationGuide/hl7.fhir.no.basis",
    "packageId" : "hl7.fhir.no.basis",
    "version" : "2.1.2"
  },
  {
    "id" : "hl7_fhir_no_domain_vitalsigns",
    "uri" : "http://hl7.no/fhir/no-domain/vitalsigns/ImplementationGuide/hl7.fhir.no.domain.vitalsigns",
    "packageId" : "hl7.fhir.no.domain.vitalsigns",
    "version" : "0.9.74"
  }],
  "definition" : {
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-internal-dependency",
      "valueCode" : "hl7.fhir.uv.tools.r4#1.3.0"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "copyrightyear"
      },
      {
        "url" : "value",
        "valueString" : "2023+"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "releaselabel"
      },
      {
        "url" : "value",
        "valueString" : "ci-build"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://hl7.no/Fhir/Profile/Diagnosis#ATC-Code"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://dips.no/fhir/StructureDefinition/DIPSDocRefContextAppointment"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://dips.no/fhir/StructureDefinition/DIPSDocRefContextEncounter"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://dips.no/fhir/StructureDefinition/DIPSDocRefOrganization"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://dips.no/fhir/StructureDefinition/DIPSDocumentReferenceApprovedByName"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://dips.no/fhir/StructureDefinition/DIPSDocumentReferenceApprovedTime"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://dips.no/fhir/StructureDefinition/DIPSDocumentReferenceApproved_By_Name"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://dips.no/fhir/StructureDefinition/DIPSDocumentReferenceApproved_Time"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://dips.no/fhir/StructureDefinition/DIPSDocumentReferenceAuthPractionerRole"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://dips.no/fhir/StructureDefinition/DIPSDocumentReferenceCreatedBy"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://dips.no/fhir/StructureDefinition/DIPSDocumentReferenceCreated_By"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://dips.no/fhir/StructureDefinition/DIPSDocumentReferenceDictatedDuration"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://dips.no/fhir/StructureDefinition/DIPSDocumentReferenceDictatedTime"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://dips.no/fhir/StructureDefinition/DIPSDocumentReferenceDocumentFormat"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://dips.no/fhir/StructureDefinition/DIPSDocumentReferenceDocument_Format"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://dips.no/fhir/StructureDefinition/DIPSDocumentReferenceEPRGroup"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://dips.no/fhir/StructureDefinition/DIPSDocumentReferenceEPR_Group"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://dips.no/fhir/StructureDefinition/DIPSDocumentReferenceEventTime"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://dips.no/fhir/StructureDefinition/DIPSDocumentReferenceEvent_Time"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://dips.no/fhir/StructureDefinition/DIPSDocumentReferenceHospitalStayId"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://dips.no/fhir/StructureDefinition/DIPSDocumentReferenceHospitalStay_Id"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://dips.no/fhir/StructureDefinition/DIPSDocumentReferenceLastChangedBy"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://dips.no/fhir/StructureDefinition/DIPSDocumentReferenceLastUpdatedTime"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://dips.no/fhir/StructureDefinition/DIPSDocumentReferenceLastUpdated_Time"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://dips.no/fhir/StructureDefinition/DIPSDocumentReferenceLast_Changed_By"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://dips.no/fhir/StructureDefinition/DIPSDocumentReferenceLocationIdExtension"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://dips.no/fhir/StructureDefinition/DIPSDocumentReferencePractitionerRole"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://dips.no/fhir/StructureDefinition/DIPSDocumentReferenceReferralId"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://dips.no/fhir/StructureDefinition/DIPSDocumentReferenceSection"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://dips.no/fhir/StructureDefinition/DIPSDocumentReferenceSubject"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://dips.no/fhir/StructureDefinition/DIPSDocumentReferenceTemplateIdExtension"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://dips.no/fhir/StructureDefinition/DIPSDocumentReferenceTerminalAddress"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://dips.no/fhir/StructureDefinition/DIPSDocumentReferenceWard"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://dips.no/fhir/StructureDefinition/DIPSDocumentReferencedictatedtime"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url"
      },
      {
        "url" : "value",
        "valueString" : "http://dips.no/fhir/StructureDefinition/DIPSR4DocumentReference"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "no-narrative"
      },
      {
        "url" : "value",
        "valueString" : "Encounter/agy27"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "no-narrative"
      },
      {
        "url" : "value",
        "valueString" : "Encounter/agy1002135"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "no-narrative"
      },
      {
        "url" : "value",
        "valueString" : "Encounter/agy100247"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "no-narrative"
      },
      {
        "url" : "value",
        "valueString" : "DocumentReference/docRef-pdf-full"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "no-narrative"
      },
      {
        "url" : "value",
        "valueString" : "DocumentReference/docref-dictated-duration-example"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "no-narrative"
      },
      {
        "url" : "value",
        "valueString" : "DocumentReference/docref-dictation-section-example"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "autoload-resources"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "template/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "input/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-qa"
      },
      {
        "url" : "value",
        "valueString" : "temp/qa"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-temp"
      },
      {
        "url" : "value",
        "valueString" : "temp/pages"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-output"
      },
      {
        "url" : "value",
        "valueString" : "output"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-suppressed-warnings"
      },
      {
        "url" : "value",
        "valueString" : "input/ignoreWarnings.txt"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-history"
      },
      {
        "url" : "value",
        "valueString" : "http://dips.no/fhir/R4/history.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "template-html"
      },
      {
        "url" : "value",
        "valueString" : "template-page.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "template-md"
      },
      {
        "url" : "value",
        "valueString" : "template-page-md.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-contact"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-context"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-copyright"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-jurisdiction"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-license"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-publisher"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-version"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-wg"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "active-tables"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "fmm-definition"
      },
      {
        "url" : "value",
        "valueString" : "http://hl7.org/fhir/versions.html#maturity"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "propagate-status"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "excludelogbinaryformat"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "tabbed-snapshots"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    }],
    "grouping" : [{
      "id" : "ObservationProfiles",
      "name" : "Observation Profiles"
    },
    {
      "id" : "DiagnosticReportProfiles",
      "name" : "DiagnosticReport Profiles"
    },
    {
      "id" : "DocumentReferenceProfiles",
      "name" : "DocumentReference Profiles"
    },
    {
      "id" : "ConditionProfiles",
      "name" : "Condition Profiles"
    },
    {
      "id" : "ProcedureProfiles",
      "name" : "Procedure Profiles"
    },
    {
      "id" : "EncounterProfiles",
      "name" : "Encounter Profiles"
    },
    {
      "id" : "EpisodeOfCareProfiles",
      "name" : "EpisodeOfCare Profiles"
    },
    {
      "id" : "ServiceRequestProfiles",
      "name" : "ServiceRequest Profiles"
    },
    {
      "id" : "AppointmentProfiles",
      "name" : "Appointment Profiles"
    },
    {
      "id" : "ScheduleProfiles",
      "name" : "Schedule Profiles"
    },
    {
      "id" : "SlotProfiles",
      "name" : "Slot Profiles"
    },
    {
      "id" : "PatientProfiles",
      "name" : "Patient Profiles"
    },
    {
      "id" : "PersonProfiles",
      "name" : "Person Profiles"
    },
    {
      "id" : "RelatedPersonProfiles",
      "name" : "RelatedPerson Profiles"
    },
    {
      "id" : "PractitionerProfiles",
      "name" : "Practitioner Profiles"
    },
    {
      "id" : "PractitionerRoleProfiles",
      "name" : "PractitionerRole Profiles"
    },
    {
      "id" : "OrganizationProfiles",
      "name" : "Organization Profiles"
    },
    {
      "id" : "HealthcareServiceProfiles",
      "name" : "HealthcareService Profiles"
    },
    {
      "id" : "LocationProfiles",
      "name" : "Location Profiles"
    },
    {
      "id" : "ReferenceProfiles",
      "name" : "Reference Profiles",
      "description" : "Constraints on the Reference datatype used by this IG's resource profiles."
    },
    {
      "id" : "SupportingReferenceProfiles",
      "name" : "Supporting Reference Profiles",
      "description" : "Profiles used only as Reference() targets by the profiles above. They constrain the identifiers a referencing profile may carry, and are not intended to be implemented directly."
    }],
    "resource" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-agy100247.html"
      }],
      "reference" : {
        "reference" : "Encounter/agy100247"
      },
      "name" : "100247",
      "exampleCanonical" : "http://dips.no/fhir/StructureDefinition/DIPSVitalSignsObservationEncounterReference"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-afn1003621.html"
      }],
      "reference" : {
        "reference" : "Condition/afn1003621"
      },
      "name" : "afn1003621",
      "exampleCanonical" : "http://dips.no/fhir/R4/StructureDefinition/DIPSR4Condition"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Condition-afn1003623.html"
      }],
      "reference" : {
        "reference" : "Condition/afn1003623"
      },
      "name" : "afn1003623",
      "exampleCanonical" : "http://dips.no/fhir/R4/StructureDefinition/DIPSR4Condition"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "PractitionerRole"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "PractitionerRole-agb1000204.html"
      }],
      "reference" : {
        "reference" : "PractitionerRole/agb1000204"
      },
      "name" : "agb1000204",
      "exampleCanonical" : "http://dips.no/fhir/R4/StructureDefinition/DIPSPractitionerRole"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "PractitionerRole"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "PractitionerRole-agb1001233.html"
      }],
      "reference" : {
        "reference" : "PractitionerRole/agb1001233"
      },
      "name" : "agb1001233",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "PractitionerRole"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "PractitionerRole-agb42.html"
      }],
      "reference" : {
        "reference" : "PractitionerRole/agb42"
      },
      "name" : "agb42",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "PractitionerRole"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "PractitionerRole-agb61.html"
      }],
      "reference" : {
        "reference" : "PractitionerRole/agb61"
      },
      "name" : "agb61",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ServiceRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ServiceRequest-agc1002251.html"
      }],
      "reference" : {
        "reference" : "ServiceRequest/agc1002251"
      },
      "name" : "agc1002251",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ServiceRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ServiceRequest-agc48.html"
      }],
      "reference" : {
        "reference" : "ServiceRequest/agc48"
      },
      "name" : "agc48",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-agv1001423.html"
      }],
      "reference" : {
        "reference" : "Procedure/agv1001423"
      },
      "name" : "agv1001423",
      "exampleCanonical" : "http://dips.no/fhir/R4/StructureDefinition/DIPSR4Procedure"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Procedure-agv1001425.html"
      }],
      "reference" : {
        "reference" : "Procedure/agv1001425"
      },
      "name" : "agv1001425",
      "exampleCanonical" : "http://dips.no/fhir/R4/StructureDefinition/DIPSR4Procedure"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-agy1002135.html"
      }],
      "reference" : {
        "reference" : "Encounter/agy1002135"
      },
      "name" : "agy1002135",
      "exampleCanonical" : "http://dips.no/fhir/R4/StructureDefinition/DIPSR4Encounter"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-agy1002679-diag.html"
      }],
      "reference" : {
        "reference" : "Encounter/agy1002679-diag"
      },
      "name" : "agy1002679-diag",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-agy1002907.html"
      }],
      "reference" : {
        "reference" : "Encounter/agy1002907"
      },
      "name" : "agy1002907",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-agy27.html"
      }],
      "reference" : {
        "reference" : "Encounter/agy27"
      },
      "name" : "agy27",
      "exampleCanonical" : "http://dips.no/fhir/R4/StructureDefinition/DIPSR4Encounter"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Appointment"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Appointment-ahi1004667.html"
      }],
      "reference" : {
        "reference" : "Appointment/ahi1004667"
      },
      "name" : "ahi1004667",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Appointment"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Appointment-ahi38.html"
      }],
      "reference" : {
        "reference" : "Appointment/ahi38"
      },
      "name" : "ahi38",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Location"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Location-ahl21.html"
      }],
      "reference" : {
        "reference" : "Location/ahl21"
      },
      "name" : "ahl21",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Location"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Location-aie1000000.html"
      }],
      "reference" : {
        "reference" : "Location/aie1000000"
      },
      "name" : "aie1000000",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Location"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Location-aie1000050.html"
      }],
      "reference" : {
        "reference" : "Location/aie1000050"
      },
      "name" : "aie1000050",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "RelatedPerson"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "RelatedPerson-ain1000001.html"
      }],
      "reference" : {
        "reference" : "RelatedPerson/ain1000001"
      },
      "name" : "ain1000001",
      "exampleCanonical" : "http://dips.no/fhir/R4/StructureDefinition/DIPSRelatedPerson"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "RelatedPerson"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "RelatedPerson-ain1000003.html"
      }],
      "reference" : {
        "reference" : "RelatedPerson/ain1000003"
      },
      "name" : "ain1000003",
      "exampleCanonical" : "http://dips.no/fhir/R4/StructureDefinition/DIPSRelatedPerson"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Person"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Person-ajf1000001.html"
      }],
      "reference" : {
        "reference" : "Person/ajf1000001"
      },
      "name" : "ajf1000001",
      "exampleCanonical" : "http://dips.no/fhir/R4/StructureDefinition/DIPSPerson"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Person"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Person-ajf242.html"
      }],
      "reference" : {
        "reference" : "Person/ajf242"
      },
      "name" : "ajf242",
      "exampleCanonical" : "http://dips.no/fhir/R4/StructureDefinition/DIPSPerson"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DocumentReference"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DocumentReference-ako1041394.html"
      }],
      "reference" : {
        "reference" : "DocumentReference/ako1041394"
      },
      "name" : "ako1041394",
      "description" : "DocumentReference",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DocumentReference"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DocumentReference-ako124.html"
      }],
      "reference" : {
        "reference" : "DocumentReference/ako124"
      },
      "name" : "ako124",
      "description" : "DocumentReference",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "RelatedPerson"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "RelatedPerson-aoz1000067cdp1000063.html"
      }],
      "reference" : {
        "reference" : "RelatedPerson/aoz1000067cdp1000063"
      },
      "name" : "aoz1000067cdp1000063",
      "exampleCanonical" : "http://dips.no/fhir/R4/StructureDefinition/DIPSRelatedPerson"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "RelatedPerson"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "RelatedPerson-aoz2007976cdp2009597.html"
      }],
      "reference" : {
        "reference" : "RelatedPerson/aoz2007976cdp2009597"
      },
      "name" : "aoz2007976cdp2009597",
      "exampleCanonical" : "http://dips.no/fhir/R4/StructureDefinition/DIPSRelatedPerson"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Appointment"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Appointment-ahi1000249.html"
      }],
      "reference" : {
        "reference" : "Appointment/ahi1000249"
      },
      "name" : "Appointment details of ahi1000249",
      "description" : "Appointment details of ahi1000249",
      "exampleCanonical" : "http://dips.no/fhir/StructureDefinition/DIPSDocRefContextAppointment"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-AppointmentReschedulingPeriodExtension.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/AppointmentReschedulingPeriodExtension"
      },
      "name" : "AppointmentReschedulingPeriodExtension",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-approvalType.html"
      }],
      "reference" : {
        "reference" : "ValueSet/approvalType"
      },
      "name" : "approvalType",
      "description" : "approvalType",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSDocumentReferenceApprovedByNameNamedQuery.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSDocumentReferenceApprovedByNameNamedQuery"
      },
      "name" : "Approved By Name (named-query URL variant)",
      "description" : "Same as DIPSDocumentReferenceApprovedByName, under the URL the documenttype / documentTypeandDepartmentid named queries actually emit. Read-only - not recognized on create or update.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSDocumentReferenceApprovedTimeNamedQuery.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSDocumentReferenceApprovedTimeNamedQuery"
      },
      "name" : "Approved Time (named-query URL variant)",
      "description" : "Same as DIPSDocumentReferenceApprovedTime, under the URL the documenttype / documentTypeandDepartmentid named queries actually emit. Read-only - not recognized on create or update.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-BankAccountNumber1.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/BankAccountNumber1"
      },
      "name" : "BankAccountNumber1",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-BankAccountNumber2.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/BankAccountNumber2"
      },
      "name" : "BankAccountNumber2",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-BedTime.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/BedTime"
      },
      "name" : "BedTime",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-BedTypeId.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/BedTypeId"
      },
      "name" : "BedTypeId",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-bloodpressure-save-complete-instance.html"
      }],
      "reference" : {
        "reference" : "Observation/bloodpressure-save-complete-instance"
      },
      "name" : "bloodpressure-save-complete-instance",
      "exampleCanonical" : "http://dips.no/fhir/StructureDefinition/DIPSVitalSignsObservationBloodpressure"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-cdp1000001.html"
      }],
      "reference" : {
        "reference" : "Patient/cdp1000001"
      },
      "name" : "cdp1000001",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-cdp1000007.html"
      }],
      "reference" : {
        "reference" : "Patient/cdp1000007"
      },
      "name" : "cdp1000007",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-cdp138.html"
      }],
      "reference" : {
        "reference" : "Patient/cdp138"
      },
      "name" : "cdp138",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-cdp2007964.html"
      }],
      "reference" : {
        "reference" : "Patient/cdp2007964"
      },
      "name" : "cdp2007964",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-cdp2008844.html"
      }],
      "reference" : {
        "reference" : "Patient/cdp2008844"
      },
      "name" : "cdp2008844",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-cdp2009672.html"
      }],
      "reference" : {
        "reference" : "Patient/cdp2009672"
      },
      "name" : "cdp2009672",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ContactTypeExtension.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ContactTypeExtension"
      },
      "name" : "ContactTypeExtension",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSDocumentReferenceCreatedByNamedQuery.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSDocumentReferenceCreatedByNamedQuery"
      },
      "name" : "Created By (named-query URL variant)",
      "description" : "Same as DIPSDocumentReferenceCreatedBy, under the URL the documenttype / documentTypeandDepartmentid named queries actually emit. Read-only - not recognized on create or update.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-Department.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/Department"
      },
      "name" : "Department",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DepartmentExtension.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DepartmentExtension"
      },
      "name" : "DepartmentExtension",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DepartmentTypeCodeId.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DepartmentTypeCodeId"
      },
      "name" : "DepartmentTypeCodeId",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DiagnoseGroupExtension.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DiagnoseGroupExtension"
      },
      "name" : "DiagnoseGroupExtension",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DiagnosisATCCode.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DiagnosisATCCode"
      },
      "name" : "Diagnosis ATC Code",
      "description" : "ATC code associated with a diagnosis, carried as a Coding on DIPS Condition.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSDocumentReferenceDictatedTimeNamedQuery.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSDocumentReferenceDictatedTimeNamedQuery"
      },
      "name" : "Dictated Time (named-query URL variant)",
      "description" : "Same as DIPSDocumentReferenceDictatedTime, under the URL the documenttype / documentTypeandDepartmentid named queries actually emit - note the all-lowercase tail. Read-only - not recognized on create or update.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DipsCanReceiveSms.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DipsCanReceiveSms"
      },
      "name" : "DIPS Can Receive SMS",
      "description" : "Indicates whether this phone number can receive SMS messages.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DipsCommentText.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DipsCommentText"
      },
      "name" : "DIPS Comment Text",
      "description" : "A free-text comment associated with this phone number.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSConditionAsserterReferenceOrg.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSConditionAsserterReferenceOrg"
      },
      "name" : "DIPS Condition Asserter Reference (Organization)",
      "description" : "Organization form of a DIPS Condition asserter. Not referenced by DIPSR4Condition - base FHIR does not permit Organization on Condition.asserter.",
      "exampleBoolean" : false,
      "groupingId" : "SupportingReferenceProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSConditionAsserterReferencePR.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSConditionAsserterReferencePR"
      },
      "name" : "DIPS Condition Asserter Reference (PractitionerRole)",
      "description" : "The practitioner role that asserted a DIPS Condition, constraining the identifiers the asserter reference may carry.",
      "exampleBoolean" : false,
      "groupingId" : "SupportingReferenceProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSConditionEncounterReference.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSConditionEncounterReference"
      },
      "name" : "DIPS Condition Encounter Reference",
      "description" : "The encounter a DIPS Condition was recorded on, constraining the identifiers the encounter reference may carry.",
      "exampleBoolean" : false,
      "groupingId" : "SupportingReferenceProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSConditionSubjectReference.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSConditionSubjectReference"
      },
      "name" : "DIPS Condition Subject Reference",
      "description" : "The patient a DIPS Condition is about, constraining the identifiers the subject reference may carry.",
      "exampleBoolean" : false,
      "groupingId" : "SupportingReferenceProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSDiagnosticReport.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSDiagnosticReport"
      },
      "name" : "DIPS DiagnosticReport",
      "description" : "DIPS profile of DiagnosticReport for laboratory reports, as served by fhir.core.r4.",
      "exampleBoolean" : false,
      "groupingId" : "DiagnosticReportProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPS-DiagnosticReport-WorkFlow.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPS-DiagnosticReport-WorkFlow"
      },
      "name" : "DIPS DiagnosticReport WorkFlow",
      "description" : "DIPS: workflow/signing state of the diagnostic report - signed, unsigned, or unsigned with urgency.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSDocumentTypeId.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSDocumentTypeId"
      },
      "name" : "DIPS Document Type Id",
      "description" : "The id of a document type associated with the monitoring type of this remote monitoring episode of care. Repeats once per associated document type.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CapabilityStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CapabilityStatement-DIPSVitalSignsObservation.html"
      }],
      "reference" : {
        "reference" : "CapabilityStatement/DIPSVitalSignsObservation"
      },
      "name" : "DIPS implementation of Vital Signs - Capability Statement",
      "description" : "DIPS implementation of Vital Signs - Capability Statement",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSIsResponsible.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSIsResponsible"
      },
      "name" : "DIPS Is Responsible",
      "description" : "Indicates whether this healthcare party is the responsible care manager for the remote monitoring episode of care.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSMonitoringNotes.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSMonitoringNotes"
      },
      "name" : "DIPS Monitoring Notes",
      "description" : "Free-text clinical notes recorded against this remote monitoring episode of care.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSProcedureEncounterReference.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSProcedureEncounterReference"
      },
      "name" : "DIPS Procedure Encounter Reference",
      "description" : "The episode of care a DIPS Procedure was recorded on, constraining the identifiers the encounter reference may carry.",
      "exampleBoolean" : false,
      "groupingId" : "SupportingReferenceProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSProcedurePerformerAuthorreference.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSProcedurePerformerAuthorreference"
      },
      "name" : "DIPS Procedure Performer Reference",
      "description" : "The practitioner role that performed a DIPS Procedure, constraining the identifiers the performer reference may carry.",
      "exampleBoolean" : false,
      "groupingId" : "SupportingReferenceProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSProcedureSubjectReference.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSProcedureSubjectReference"
      },
      "name" : "DIPS Procedure Subject Reference",
      "description" : "The patient a DIPS Procedure is about, constraining the identifiers the subject reference may carry.",
      "exampleBoolean" : false,
      "groupingId" : "SupportingReferenceProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSR4Condition.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSR4Condition"
      },
      "name" : "DIPS R4 Condition",
      "description" : "Diagnosis registered on a patient in DIPS Arena. Resource ids carry the `afn` prefix.",
      "exampleBoolean" : false,
      "groupingId" : "ConditionProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSR4Procedure.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSR4Procedure"
      },
      "name" : "DIPS R4 Procedure",
      "description" : "Procedure registered on a patient in DIPS Arena. Resource ids carry the `agv` prefix.",
      "exampleBoolean" : false,
      "groupingId" : "ProcedureProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSReferenceLocation.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSReferenceLocation"
      },
      "name" : "DIPS Reference Location",
      "description" : "A reference to the DIPS hospital Location, modelled as an Organization, associated with this remote monitoring episode of care.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSReferenceSection.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSReferenceSection"
      },
      "name" : "DIPS Reference Section",
      "description" : "A reference to the DIPS hospital Section, modelled as an Organization, associated with this remote monitoring episode of care.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSReferenceWard.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSReferenceWard"
      },
      "name" : "DIPS Reference Ward",
      "description" : "A reference to the DIPS hospital Ward, modelled as an Organization, associated with this remote monitoring episode of care.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSRemoteMonitoring.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSRemoteMonitoring"
      },
      "name" : "DIPS Remote Monitoring",
      "description" : "An EpisodeOfCare used to track a patient's remote monitoring period, including free-text monitoring notes and references to the responsible hospital Location, Section, and Ward.",
      "exampleBoolean" : false,
      "groupingId" : "EpisodeOfCareProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSVitalSignsObservationBloodpressure.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSVitalSignsObservationBloodpressure"
      },
      "name" : "DIPS Vital Signs Observation - Blood Pressure",
      "description" : "DIPS profile for Blood Pressure including some extensions",
      "exampleBoolean" : false,
      "groupingId" : "ObservationProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSVitalSignsObservationBodyHeight.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSVitalSignsObservationBodyHeight"
      },
      "name" : "DIPS Vital Signs Observation - Body Height",
      "description" : "DIPS profile for Body Height including some extensions",
      "exampleBoolean" : false,
      "groupingId" : "ObservationProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSVitalSignsObservationBodyMassIndex.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSVitalSignsObservationBodyMassIndex"
      },
      "name" : "DIPS Vital Signs Observation - Body Mass Index(BMI)",
      "description" : "DIPS profile for Body Mass Index(BMI) including some extensions",
      "exampleBoolean" : false,
      "groupingId" : "ObservationProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSVitalSignsObservationBodyTemp.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSVitalSignsObservationBodyTemp"
      },
      "name" : "DIPS Vital Signs Observation - Body Temperature",
      "description" : "DIPS profile for Body Temperature including some extensions",
      "exampleBoolean" : false,
      "groupingId" : "ObservationProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSVitalSignsObservationBodyWeight.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSVitalSignsObservationBodyWeight"
      },
      "name" : "DIPS Vital Signs Observation - Body Weight",
      "description" : "DIPS profile for Body Weight including some extensions",
      "exampleBoolean" : false,
      "groupingId" : "ObservationProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSVitalSignsObservationGCS.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSVitalSignsObservationGCS"
      },
      "name" : "DIPS Vital Signs Observation - Glasgow Coma Scale",
      "description" : "Fifteen point scale used to assess impairment of consciousness in response to defined stimuli. More correctly known as the Modified Glasgow coma scale.",
      "exampleBoolean" : false,
      "groupingId" : "ObservationProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSVitalSignsObservationHeartRate.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSVitalSignsObservationHeartRate"
      },
      "name" : "DIPS Vital Signs Observation - Heart Rate",
      "description" : "DIPS profile for Heart Rate including some extensions",
      "exampleBoolean" : false,
      "groupingId" : "ObservationProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSVitalSignsObservationConsciousness.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSVitalSignsObservationConsciousness"
      },
      "name" : "DIPS Vital Signs Observation - Level of Consciousness",
      "description" : "DIPS profile for Level of Consciousness including some extensions",
      "exampleBoolean" : false,
      "groupingId" : "ObservationProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSVitalSignsObservationNews2Score.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSVitalSignsObservationNews2Score"
      },
      "name" : "DIPS Vital Signs Observation - NEWS2",
      "description" : "DIPS profile for NEWS2 including some extensions",
      "exampleBoolean" : false,
      "groupingId" : "ObservationProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSVitalSignsObservationOxygenSaturation.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSVitalSignsObservationOxygenSaturation"
      },
      "name" : "DIPS Vital Signs Observation - Oxygen Saturation",
      "description" : "DIPS profile for Oxygen Saturation including some extensions",
      "exampleBoolean" : false,
      "groupingId" : "ObservationProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSVitalSignsObservationPulse.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSVitalSignsObservationPulse"
      },
      "name" : "DIPS Vital Signs Observation - Pulse",
      "description" : "DIPS profile for Pulse including some extensions",
      "exampleBoolean" : false,
      "groupingId" : "ObservationProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSVitalSignsObservationqSOFA.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSVitalSignsObservationqSOFA"
      },
      "name" : "DIPS Vital Signs Observation - qSOFA",
      "description" : "Quick Sepsis-related Organ Failure Assessment (qSOFA) is a simplified version of the SOFA score, which is used outside intensive care units to quickly assess sepsis risk in adults.",
      "exampleBoolean" : false,
      "groupingId" : "ObservationProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSVitalSignsObservationRespirationRate.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSVitalSignsObservationRespirationRate"
      },
      "name" : "DIPS Vital Signs Observation - Respiration Rate",
      "description" : "DIPS profile for Respiration Rate including some extensions",
      "exampleBoolean" : false,
      "groupingId" : "ObservationProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-dips-blood-pressure-create.html"
      }],
      "reference" : {
        "reference" : "Observation/dips-blood-pressure-create"
      },
      "name" : "dips-blood-pressure-create",
      "exampleCanonical" : "http://dips.no/fhir/StructureDefinition/DIPSVitalSignsObservationBloodpressure"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-dips-bloodpressureexample.html"
      }],
      "reference" : {
        "reference" : "Observation/dips-bloodpressureexample"
      },
      "name" : "dips-bloodpressureexample",
      "exampleCanonical" : "http://dips.no/fhir/StructureDefinition/DIPSVitalSignsObservationBloodpressure"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-dips-body-height-create.html"
      }],
      "reference" : {
        "reference" : "Observation/dips-body-height-create"
      },
      "name" : "dips-body-height-create",
      "exampleCanonical" : "http://dips.no/fhir/StructureDefinition/DIPSVitalSignsObservationBodyHeight"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-dips-body-mass-index-create.html"
      }],
      "reference" : {
        "reference" : "Observation/dips-body-mass-index-create"
      },
      "name" : "dips-body-mass-index-create",
      "exampleCanonical" : "http://dips.no/fhir/StructureDefinition/DIPSVitalSignsObservationBodyMassIndex"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-dips-body-temperature-create.html"
      }],
      "reference" : {
        "reference" : "Observation/dips-body-temperature-create"
      },
      "name" : "dips-body-temperature-create",
      "exampleCanonical" : "http://dips.no/fhir/StructureDefinition/DIPSVitalSignsObservationBodyTemp"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-dips-body-weight-create.html"
      }],
      "reference" : {
        "reference" : "Observation/dips-body-weight-create"
      },
      "name" : "dips-body-weight-create",
      "exampleCanonical" : "http://dips.no/fhir/StructureDefinition/DIPSVitalSignsObservationBodyWeight"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-dips-consciousness-create.html"
      }],
      "reference" : {
        "reference" : "Observation/dips-consciousness-create"
      },
      "name" : "dips-consciousness-create",
      "exampleCanonical" : "http://dips.no/fhir/StructureDefinition/DIPSVitalSignsObservationConsciousness"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-dips-gcs-create.html"
      }],
      "reference" : {
        "reference" : "Observation/dips-gcs-create"
      },
      "name" : "dips-gcs-create",
      "exampleCanonical" : "http://dips.no/fhir/StructureDefinition/DIPSVitalSignsObservationGCS"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-dips-heart-rate-create.html"
      }],
      "reference" : {
        "reference" : "Observation/dips-heart-rate-create"
      },
      "name" : "dips-heart-rate-create",
      "exampleCanonical" : "http://dips.no/fhir/StructureDefinition/DIPSVitalSignsObservationHeartRate"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-dips-news2-create.html"
      }],
      "reference" : {
        "reference" : "Observation/dips-news2-create"
      },
      "name" : "dips-news2-create",
      "exampleCanonical" : "http://dips.no/fhir/StructureDefinition/DIPSVitalSignsObservationNews2Score"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-dips-oxygen-saturation-create.html"
      }],
      "reference" : {
        "reference" : "Observation/dips-oxygen-saturation-create"
      },
      "name" : "dips-oxygen-saturation-create",
      "exampleCanonical" : "http://dips.no/fhir/StructureDefinition/DIPSVitalSignsObservationOxygenSaturation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DipsPatientLanguageId.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DipsPatientLanguageId"
      },
      "name" : "dips-patient-language-id",
      "description" : "Defines the Id of the language that patient speaks",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-dips-QSOFAScore-create.html"
      }],
      "reference" : {
        "reference" : "Observation/dips-QSOFAScore-create"
      },
      "name" : "dips-QSOFAScore-create",
      "exampleCanonical" : "http://dips.no/fhir/StructureDefinition/DIPSVitalSignsObservationqSOFA"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-dips-respiratory-rate-create.html"
      }],
      "reference" : {
        "reference" : "Observation/dips-respiratory-rate-create"
      },
      "name" : "dips-respiratory-rate-create",
      "exampleCanonical" : "http://dips.no/fhir/StructureDefinition/DIPSVitalSignsObservationRespirationRate"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSAppointment.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSAppointment"
      },
      "name" : "DIPSAppointment",
      "exampleBoolean" : false,
      "groupingId" : "AppointmentProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSAppointmentSchedule.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSAppointmentSchedule"
      },
      "name" : "DIPSAppointmentSchedule",
      "exampleBoolean" : false,
      "groupingId" : "ScheduleProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSBasisLabObservationR4.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSBasisLabObservationR4"
      },
      "name" : "DIPSBasisLabObservationR4",
      "exampleBoolean" : false,
      "groupingId" : "ObservationProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSBasisOrganizationR4Reference.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSBasisOrganizationR4Reference"
      },
      "name" : "DIPSBasisOrganizationR4Reference",
      "exampleBoolean" : false,
      "groupingId" : "SupportingReferenceProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:complex-type"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSBasisPatientR4Reference.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSBasisPatientR4Reference"
      },
      "name" : "DIPSBasisPatientR4Reference",
      "exampleBoolean" : false,
      "groupingId" : "ReferenceProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSBasisPractitionerR4.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSBasisPractitionerR4"
      },
      "name" : "DIPSBasisPractitionerR4",
      "exampleBoolean" : false,
      "groupingId" : "SupportingReferenceProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSBasisPractitionerRoleR4Reference.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSBasisPractitionerRoleR4Reference"
      },
      "name" : "DIPSBasisPractitionerRoleR4Reference",
      "exampleBoolean" : false,
      "groupingId" : "SupportingReferenceProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-DIPSBodyMassIndexMeasurementMethod.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/DIPSBodyMassIndexMeasurementMethod"
      },
      "name" : "DIPSBodyMassIndexMeasurementMethod",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-DipsCoding1003ValueSet.html"
      }],
      "reference" : {
        "reference" : "ValueSet/DipsCoding1003ValueSet"
      },
      "name" : "DipsCoding1003ValueSet",
      "description" : "Value Sets of DipsCoding1003ValueSet",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:complex-type"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSDiagnosticOrderSpecimenReference.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSDiagnosticOrderSpecimenReference"
      },
      "name" : "DIPSDiagnosticOrderSpecimenReference",
      "exampleBoolean" : false,
      "groupingId" : "ReferenceProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSDiagnosticReportOrganizationReference.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSDiagnosticReportOrganizationReference"
      },
      "name" : "DIPSDiagnosticReportOrganizationReference",
      "exampleBoolean" : false,
      "groupingId" : "SupportingReferenceProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSDiagnosticReportPractitionerReference.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSDiagnosticReportPractitionerReference"
      },
      "name" : "DIPSDiagnosticReportPractitionerReference",
      "exampleBoolean" : false,
      "groupingId" : "SupportingReferenceProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSDiagnosticReportSubjectReference.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSDiagnosticReportSubjectReference"
      },
      "name" : "DIPSDiagnosticReportSubjectReference",
      "exampleBoolean" : false,
      "groupingId" : "SupportingReferenceProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSDocRefContextAppointment.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSDocRefContextAppointment"
      },
      "name" : "DIPSDocumentReferenceAppointment",
      "description" : "DIPS DocumentReference Appointment Profile",
      "exampleBoolean" : false,
      "groupingId" : "SupportingReferenceProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSDocumentReferenceApprovedByName.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSDocumentReferenceApprovedByName"
      },
      "name" : "DIPSDocumentReferenceApprovedByName",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSDocumentReferenceApprovedTime.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSDocumentReferenceApprovedTime"
      },
      "name" : "DIPSDocumentReferenceApprovedTime",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSDocumentReferenceAuthPractionerRole.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSDocumentReferenceAuthPractionerRole"
      },
      "name" : "DIPSDocumentReferenceAuthPractionerRole",
      "description" : "PractionerRole Profile for Authenticator of DocumentReference",
      "exampleBoolean" : false,
      "groupingId" : "SupportingReferenceProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSDocumentReferenceCreatedBy.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSDocumentReferenceCreatedBy"
      },
      "name" : "DIPSDocumentReferenceCreatedBy",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSDocumentReferenceDictatedDuration.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSDocumentReferenceDictatedDuration"
      },
      "name" : "DIPSDocumentReferenceDictatedDuration",
      "description" : "DictatedDuration can be mentioned either in seconds (s), minutes (min), hours (h)\nor days (d) in the POST request. However, the response will always return in (s)\nseconds.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSDocumentReferenceDictatedTime.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSDocumentReferenceDictatedTime"
      },
      "name" : "DIPSDocumentReferenceDictatedTime",
      "description" : "This Extension is a mandatory property in creation and update of dictation",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSDocumentReferenceDocumentFormat.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSDocumentReferenceDocumentFormat"
      },
      "name" : "DIPSDocumentReferenceDocumentFormat",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSDocumentReferenceEPRGroup.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSDocumentReferenceEPRGroup"
      },
      "name" : "DIPSDocumentReferenceEPRGroup",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSDocumentReferenceEventTime.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSDocumentReferenceEventTime"
      },
      "name" : "DIPSDocumentReferenceEventTime",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSDocumentReferenceHospitalStayId.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSDocumentReferenceHospitalStayId"
      },
      "name" : "DIPSDocumentReferenceHospitalStayId",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSDocumentReferenceLastChangedBy.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSDocumentReferenceLastChangedBy"
      },
      "name" : "DIPSDocumentReferenceLastChangedBy",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSDocumentReferenceLastUpdatedTime.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSDocumentReferenceLastUpdatedTime"
      },
      "name" : "DIPSDocumentReferenceLastUpdatedTime",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSDocumentReferenceLocationIdExtension.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSDocumentReferenceLocationIdExtension"
      },
      "name" : "DIPSDocumentReferenceLocationIdExtension",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSDocumentReferencePractitionerRole.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSDocumentReferencePractitionerRole"
      },
      "name" : "DIPSDocumentReferencePractitioner",
      "description" : "Practioner Profile For DocumentReference",
      "exampleBoolean" : false,
      "groupingId" : "SupportingReferenceProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSDocumentReferenceReferralId.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSDocumentReferenceReferralId"
      },
      "name" : "DIPSDocumentReferenceReferralId",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSDocumentReferenceSection.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSDocumentReferenceSection"
      },
      "name" : "DIPSDocumentReferenceSection",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSDocumentReferenceSubject.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSDocumentReferenceSubject"
      },
      "name" : "DIPSDocumentReferenceSubject",
      "description" : "Patient Profile of DocumentReference",
      "exampleBoolean" : false,
      "groupingId" : "SupportingReferenceProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSDocumentReferenceTemplateIdExtension.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSDocumentReferenceTemplateIdExtension"
      },
      "name" : "DIPSDocumentReferenceTemplateIdExtension",
      "description" : "This is a mandatory property in create / update dictation",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSDocumentReferenceTerminalAddress.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSDocumentReferenceTerminalAddress"
      },
      "name" : "DIPSDocumentReferenceTerminalAddress",
      "description" : "As per the current implementation, saved documents are moved out of locked state to unlocked state\nafter a document is created. The device terminal address can be sent in the document create post data\nas an extension",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSDocumentReferenceWard.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSDocumentReferenceWard"
      },
      "name" : "DIPSDocumentReferenceWard",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSEncounterLocation.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSEncounterLocation"
      },
      "name" : "DIPSEncounterLocation",
      "exampleBoolean" : false,
      "groupingId" : "SupportingReferenceProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSEncounterOrganization.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSEncounterOrganization"
      },
      "name" : "DIPSEncounterOrganization",
      "exampleBoolean" : false,
      "groupingId" : "SupportingReferenceProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSEncounterPractitionerReference.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSEncounterPractitionerReference"
      },
      "name" : "DIPSEncounterPractitionerReference",
      "exampleBoolean" : false,
      "groupingId" : "SupportingReferenceProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSEncounterServiceRequest.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSEncounterServiceRequest"
      },
      "name" : "DIPSEncounterServiceRequest",
      "exampleBoolean" : false,
      "groupingId" : "ServiceRequestProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSEncounterSubjectReference.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSEncounterSubjectReference"
      },
      "name" : "DIPSEncounterSubjectReference",
      "exampleBoolean" : false,
      "groupingId" : "SupportingReferenceProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-DIPSEncounterTypeCom.html"
      }],
      "reference" : {
        "reference" : "ValueSet/DIPSEncounterTypeCom"
      },
      "name" : "DIPSEncounterTypeCom",
      "description" : "Have volven codesystems and rest of the namesystem",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-DIPSEncounterV3.html"
      }],
      "reference" : {
        "reference" : "ValueSet/DIPSEncounterV3"
      },
      "name" : "DIPSEncounterV3",
      "description" : "Codes representing body site for blood pressure",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-DIPSGCSEyeOpeningScore.html"
      }],
      "reference" : {
        "reference" : "ValueSet/DIPSGCSEyeOpeningScore"
      },
      "name" : "DIPSGCSEyeOpeningScore",
      "description" : "ValueSet of GCS Eye OpeningScore",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-DIPSGCSEyeOpeningScoreCodeSystem.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/DIPSGCSEyeOpeningScoreCodeSystem"
      },
      "name" : "DIPSGCSEyeOpeningScoreCodeSystem",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-DIPSGCSMotorScore.html"
      }],
      "reference" : {
        "reference" : "ValueSet/DIPSGCSMotorScore"
      },
      "name" : "DIPSGCSMotorScore",
      "description" : "ValueSet of GCS Motor Score",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-DIPSGCSMotorScoreCodeSystem.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/DIPSGCSMotorScoreCodeSystem"
      },
      "name" : "DIPSGCSMotorScoreCodeSystem",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-DIPSGCSVerbalScore.html"
      }],
      "reference" : {
        "reference" : "ValueSet/DIPSGCSVerbalScore"
      },
      "name" : "DIPSGCSVerbalScore",
      "description" : "ValueSet of GCS Verbal Score",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-DIPSGCSVerbalScoreCodeSystem.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/DIPSGCSVerbalScoreCodeSystem"
      },
      "name" : "DIPSGCSVerbalScoreCodeSystem",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSHealthcareService.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSHealthcareService"
      },
      "name" : "DIPSHealthcareService",
      "exampleBoolean" : false,
      "groupingId" : "HealthcareServiceProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSHealthcareServiceAddress.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSHealthcareServiceAddress"
      },
      "name" : "DIPSHealthcareServiceAddress",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSHealthcareServiceCommunicationProtocol.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSHealthcareServiceCommunicationProtocol"
      },
      "name" : "DIPSHealthcareServiceCommunicationProtocol",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSHealthcareServiceDepartment.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSHealthcareServiceDepartment"
      },
      "name" : "DIPSHealthcareServiceDepartment",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSHealthcareServiceHospital.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSHealthcareServiceHospital"
      },
      "name" : "DIPSHealthcareServiceHospital",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSHealthcareServiceIsPaperCopy.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSHealthcareServiceIsPaperCopy"
      },
      "name" : "DIPSHealthcareServiceIsPaperCopy",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSHealthcareServiceSection.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSHealthcareServiceSection"
      },
      "name" : "DIPSHealthcareServiceSection",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-DIPSHealthcareServiceTypes.html"
      }],
      "reference" : {
        "reference" : "ValueSet/DIPSHealthcareServiceTypes"
      },
      "name" : "DIPSHealthcareServiceTypes",
      "description" : "Value Sets of DIPSHealthcareServiceTypes",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSHealthcareServiceWard.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSHealthcareServiceWard"
      },
      "name" : "DIPSHealthcareServiceWard",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSHospitalStayEncounter.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSHospitalStayEncounter"
      },
      "name" : "DIPSHospitalStayEncounter",
      "exampleBoolean" : false,
      "groupingId" : "EncounterProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSJournalId.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSJournalId"
      },
      "name" : "DIPSJournalId",
      "description" : "DIPS extension for Journal ID, common for all DIPS vital sign profiles",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:complex-type"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSLabsObservationReference.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSLabsObservationReference"
      },
      "name" : "DIPSLabsObservationReference",
      "exampleBoolean" : false,
      "groupingId" : "ReferenceProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSLocation.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSLocation"
      },
      "name" : "DIPSLocation",
      "exampleBoolean" : false,
      "groupingId" : "LocationProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-DIPSLocation.html"
      }],
      "reference" : {
        "reference" : "ValueSet/DIPSLocation"
      },
      "name" : "DIPSLocation",
      "description" : "DIPSLocation",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-DIPSLocation.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/DIPSLocation"
      },
      "name" : "DIPSLocation",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DipsLocationExtension.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DipsLocationExtension"
      },
      "name" : "DipsLocationExtension",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSLocationReference.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSLocationReference"
      },
      "name" : "DIPSLocationReference",
      "exampleBoolean" : false,
      "groupingId" : "SupportingReferenceProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-DIPSLocationTopLevel.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/DIPSLocationTopLevel"
      },
      "name" : "DIPSLocationTopLevel",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-DIPSMeasurementMethod.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/DIPSMeasurementMethod"
      },
      "name" : "DIPSMeasurementMethod",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSObservationSubjectReference.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSObservationSubjectReference"
      },
      "name" : "DIPSObservationSubjectReference",
      "exampleBoolean" : false,
      "groupingId" : "SupportingReferenceProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSOrganization.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSOrganization"
      },
      "name" : "DIPSOrganization",
      "exampleBoolean" : false,
      "groupingId" : "OrganizationProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DipsOrganizationRef.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DipsOrganizationRef"
      },
      "name" : "DipsOrganizationRef",
      "exampleBoolean" : false,
      "groupingId" : "SupportingReferenceProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:complex-type"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSOrganizationReference.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSOrganizationReference"
      },
      "name" : "DIPSOrganizationReference",
      "exampleBoolean" : false,
      "groupingId" : "ReferenceProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSPatient.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSPatient"
      },
      "name" : "DIPSPatient",
      "exampleBoolean" : false,
      "groupingId" : "PatientProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSPatientContactIdentifier.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSPatientContactIdentifier"
      },
      "name" : "DIPSPatientContactIdentifier",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSPatientContactPractitionerRoleName.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSPatientContactPractitionerRoleName"
      },
      "name" : "DIPSPatientContactPractitionerRoleName",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DipsPatientDeathComment.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DipsPatientDeathComment"
      },
      "name" : "DipsPatientDeathComment",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DipsPatientDeathRegisteredBy.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DipsPatientDeathRegisteredBy"
      },
      "name" : "DipsPatientDeathRegisteredBy",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DipsPatientDeathRegisteredTime.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DipsPatientDeathRegisteredTime"
      },
      "name" : "DipsPatientDeathRegisteredTime",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DipsPatientHospitalSectorId.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DipsPatientHospitalSectorId"
      },
      "name" : "DipsPatientHospitalSectorId",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DipsPatientHospitalSectorName.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DipsPatientHospitalSectorName"
      },
      "name" : "DipsPatientHospitalSectorName",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DipsPatientMunicipality.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DipsPatientMunicipality"
      },
      "name" : "DipsPatientMunicipality",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DipsPatientPhoneTypeId.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DipsPatientPhoneTypeId"
      },
      "name" : "DipsPatientPhoneTypeId",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DipsPatientStateName.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DipsPatientStateName"
      },
      "name" : "DipsPatientStateName",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSPerson.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSPerson"
      },
      "name" : "DIPSPerson",
      "exampleBoolean" : false,
      "groupingId" : "PersonProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSPersonDeathComment.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSPersonDeathComment"
      },
      "name" : "DIPSPersonDeathComment",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSPersonDeathRegisteredBy.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSPersonDeathRegisteredBy"
      },
      "name" : "DIPSPersonDeathRegisteredBy",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSPersonDeathRegisteredTime.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSPersonDeathRegisteredTime"
      },
      "name" : "DIPSPersonDeathRegisteredTime",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSPersonHospitalSectorId.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSPersonHospitalSectorId"
      },
      "name" : "DIPSPersonHospitalSectorId",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSPersonHospitalSectorName.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSPersonHospitalSectorName"
      },
      "name" : "DIPSPersonHospitalSectorName",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSPersonLanguage.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSPersonLanguage"
      },
      "name" : "DIPSPersonLanguage",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSPersonLastOfficialAddressSyncTime.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSPersonLastOfficialAddressSyncTime"
      },
      "name" : "DIPSPersonLastOfficialAddressSyncTime",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSPersonMunicipality.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSPersonMunicipality"
      },
      "name" : "DIPSPersonMunicipality",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSPersonStateName.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSPersonStateName"
      },
      "name" : "DIPSPersonStateName",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSPractitioner.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSPractitioner"
      },
      "name" : "DIPSPractitioner",
      "exampleBoolean" : false,
      "groupingId" : "PractitionerProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:complex-type"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSPractitionerReference.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSPractitionerReference"
      },
      "name" : "DIPSPractitionerReference",
      "exampleBoolean" : false,
      "groupingId" : "ReferenceProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSPractitionerRole.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSPractitionerRole"
      },
      "name" : "DIPSPractitionerRole",
      "exampleBoolean" : false,
      "groupingId" : "PractitionerRoleProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSPractitionerRoleCommunicationProtocol.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSPractitionerRoleCommunicationProtocol"
      },
      "name" : "DIPSPractitionerRoleCommunicationProtocol",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSPractitionerRoleCommunicationType.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSPractitionerRoleCommunicationType"
      },
      "name" : "DIPSPractitionerRoleCommunicationType",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSPractitionerRoleCommunicationTypeId.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSPractitionerRoleCommunicationTypeId"
      },
      "name" : "DIPSPractitionerRoleCommunicationTypeId",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSPractitionerRoleDipsSignature.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSPractitionerRoleDipsSignature"
      },
      "name" : "DIPSPractitionerRoleDipsSignature",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSPractitionerRoleHcpRoleName.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSPractitionerRoleHcpRoleName"
      },
      "name" : "DIPSPractitionerRoleHcpRoleName",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSPractitionerRoleHealthCarePartyDepartment.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSPractitionerRoleHealthCarePartyDepartment"
      },
      "name" : "DIPSPractitionerRoleHealthCarePartyDepartment",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSPractitionerRoleHealthCarePartyType.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSPractitionerRoleHealthCarePartyType"
      },
      "name" : "DIPSPractitionerRoleHealthCarePartyType",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSPractitionerRoleHealthCarePosition.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSPractitionerRoleHealthCarePosition"
      },
      "name" : "DIPSPractitionerRoleHealthCarePosition",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSPractitionerRoleHospital.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSPractitionerRoleHospital"
      },
      "name" : "DIPSPractitionerRoleHospital",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSPractitionerRoleIsPaperCopy.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSPractitionerRoleIsPaperCopy"
      },
      "name" : "DIPSPractitionerRoleIsPaperCopy",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:complex-type"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSPractitionerRoleReference.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSPractitionerRoleReference"
      },
      "name" : "DIPSPractitionerRoleReference",
      "exampleBoolean" : false,
      "groupingId" : "ReferenceProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSPractitionerRoleSection.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSPractitionerRoleSection"
      },
      "name" : "DIPSPractitionerRoleSection",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSPractitionerRoleUserRoleDepartment.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSPractitionerRoleUserRoleDepartment"
      },
      "name" : "DIPSPractitionerRoleUserRoleDepartment",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSPractitionerRoleUserRoleId.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSPractitionerRoleUserRoleId"
      },
      "name" : "DIPSPractitionerRoleUserRoleId",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSPractitionerRoleUserRoleLastUpdated.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSPractitionerRoleUserRoleLastUpdated"
      },
      "name" : "DIPSPractitionerRoleUserRoleLastUpdated",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSPractitionerRoleUserRoleName.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSPractitionerRoleUserRoleName"
      },
      "name" : "DIPSPractitionerRoleUserRoleName",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSPractitionerRoleWard.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSPractitionerRoleWard"
      },
      "name" : "DIPSPractitionerRoleWard",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSPractitionerSpecialist.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSPractitionerSpecialist"
      },
      "name" : "DIPSPractitionerSpecialist",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-DIPSQSOFAScoreBPCodeSystem.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/DIPSQSOFAScoreBPCodeSystem"
      },
      "name" : "DIPSQSOFAScoreBPCodeSystem",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-DIPSQSOFAScoreBPValueSet.html"
      }],
      "reference" : {
        "reference" : "ValueSet/DIPSQSOFAScoreBPValueSet"
      },
      "name" : "DIPSQSOFAScoreBPValueSet",
      "description" : "ValueSet of qSOFA Blood Pressure",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-DIPSQSOFAScoreMentalStatusCodeSystem.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/DIPSQSOFAScoreMentalStatusCodeSystem"
      },
      "name" : "DIPSQSOFAScoreMentalStatusCodeSystem",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-DIPSQSOFAScoreMentalStatusValueSet.html"
      }],
      "reference" : {
        "reference" : "ValueSet/DIPSQSOFAScoreMentalStatusValueSet"
      },
      "name" : "DIPSQSOFAScoreMentalStatusValueSet",
      "description" : "ValueSet of qSOFA Mental Status",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-DIPSQSOFAScoreResRateCodeSystem.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/DIPSQSOFAScoreResRateCodeSystem"
      },
      "name" : "DIPSQSOFAScoreResRateCodeSystem",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-DIPSQSOFAScoreResRateValueSet.html"
      }],
      "reference" : {
        "reference" : "ValueSet/DIPSQSOFAScoreResRateValueSet"
      },
      "name" : "DIPSQSOFAScoreResRateValueSet",
      "description" : "ValueSet of qSOFA Respiration Rate",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSR4DocumentReference.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSR4DocumentReference"
      },
      "name" : "DIPSR4DocumentReference",
      "exampleBoolean" : false,
      "groupingId" : "DocumentReferenceProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSR4Encounter.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSR4Encounter"
      },
      "name" : "DIPSR4Encounter",
      "exampleBoolean" : false,
      "groupingId" : "EncounterProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSRelatedPerson.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSRelatedPerson"
      },
      "name" : "DIPSRelatedPerson",
      "exampleBoolean" : false,
      "groupingId" : "RelatedPersonProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSRelatedPersonAdditionalInformation.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSRelatedPersonAdditionalInformation"
      },
      "name" : "DIPSRelatedPersonAdditionalInformation",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSRelatedPersonAppointedByMunicipality.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSRelatedPersonAppointedByMunicipality"
      },
      "name" : "DIPSRelatedPersonAppointedByMunicipality",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSRelatedPersonKinship.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSRelatedPersonKinship"
      },
      "name" : "DIPSRelatedPersonKinship",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSRelatedPersonParentalResponsibility.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSRelatedPersonParentalResponsibility"
      },
      "name" : "DIPSRelatedPersonParentalResponsibility",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSRelatedPersonResponsibleRequisitioner.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSRelatedPersonResponsibleRequisitioner"
      },
      "name" : "DIPSRelatedPersonResponsibleRequisitioner",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSSubjectReference.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSSubjectReference"
      },
      "name" : "DIPSSubjectReference",
      "exampleBoolean" : false,
      "groupingId" : "SupportingReferenceProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSVitalSignsHeartRhythmIrregularity.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSVitalSignsHeartRhythmIrregularity"
      },
      "name" : "DIPSVitalSignsHeartRhythmIrregularity",
      "description" : "Patterns of heart rate",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-DIPSVitalSignsHeartRhythmIrregularity.html"
      }],
      "reference" : {
        "reference" : "ValueSet/DIPSVitalSignsHeartRhythmIrregularity"
      },
      "name" : "DIPSVitalSignsHeartRhythmIrregularity",
      "description" : "Codes representing heart rhythm irregularity for heart rate",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSVitalSignsLocation.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSVitalSignsLocation"
      },
      "name" : "DIPSVitalSignsLocation",
      "description" : "the physical location where the care delivery took place",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-DIPSVitalSignsObservationBloodPressureMeasurementMethod.html"
      }],
      "reference" : {
        "reference" : "ValueSet/DIPSVitalSignsObservationBloodPressureMeasurementMethod"
      },
      "name" : "DIPSVitalSignsObservationBloodPressureMeasurementMethod",
      "description" : "Codes representing measurement method",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSVitalSignsObservationBodyMassIndexFormula.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSVitalSignsObservationBodyMassIndexFormula"
      },
      "name" : "DIPSVitalSignsObservationBodyMassIndexFormula",
      "description" : "Formula used to derive the body mass index.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-DIPSVitalSignsObservationBodyMassIndexFormula.html"
      }],
      "reference" : {
        "reference" : "ValueSet/DIPSVitalSignsObservationBodyMassIndexFormula"
      },
      "name" : "DIPSVitalSignsObservationBodyMassIndexFormula",
      "description" : "Value set for DIPS Body Mass Index Formula Measurement methods",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-DIPSVitalSignsObservationBodySite.html"
      }],
      "reference" : {
        "reference" : "ValueSet/DIPSVitalSignsObservationBodySite"
      },
      "name" : "DIPSVitalSignsObservationBodySite",
      "description" : "Value set for DIPS body sites used for body temperature measurement",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSVitalSignsObservationConfoundingFactor.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSVitalSignsObservationConfoundingFactor"
      },
      "name" : "DIPSVitalSignsObservationConfoundingFactor",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-DIPSVitalSignsObservationConsciousness.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/DIPSVitalSignsObservationConsciousness"
      },
      "name" : "DIPSVitalSignsObservationConsciousness",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSVitalSignsObservationEncounterReference.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSVitalSignsObservationEncounterReference"
      },
      "name" : "DIPSVitalSignsObservationEncounterReference",
      "description" : "Encounter with Episode Of Care and Planned Contact",
      "exampleBoolean" : false,
      "groupingId" : "SupportingReferenceProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-DIPSVitalSignsObservationHeartRateMeasurementMethod.html"
      }],
      "reference" : {
        "reference" : "ValueSet/DIPSVitalSignsObservationHeartRateMeasurementMethod"
      },
      "name" : "DIPSVitalSignsObservationHeartRateMeasurementMethod",
      "description" : "Codes representing measurement method",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSVitalSignsObservationOrganizationReference.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSVitalSignsObservationOrganizationReference"
      },
      "name" : "DIPSVitalSignsObservationOrganizationReference",
      "exampleBoolean" : false,
      "groupingId" : "SupportingReferenceProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSVitalSignsObservationPrePostduktal.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSVitalSignsObservationPrePostduktal"
      },
      "name" : "DIPSVitalSignsObservationPrePostduktal",
      "description" : "Description of the pre/post/intermediate level of ductal",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-DIPSVitalSignsObservationPrePostduktal.html"
      }],
      "reference" : {
        "reference" : "ValueSet/DIPSVitalSignsObservationPrePostduktal"
      },
      "name" : "DIPSVitalSignsObservationPrePostduktal",
      "description" : "Codes representing pre/post ductal",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-DIPSVitalSignsObservationPrePostduktal.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/DIPSVitalSignsObservationPrePostduktal"
      },
      "name" : "DIPSVitalSignsObservationPrePostduktal",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-DIPSVitalSignsObservationPulseBodySite.html"
      }],
      "reference" : {
        "reference" : "ValueSet/DIPSVitalSignsObservationPulseBodySite"
      },
      "name" : "DIPSVitalSignsObservationPulseBodySite",
      "description" : "Codes representing Body site for Pulse",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-DIPSVitalSignsObservationPulseMeasurementMethod.html"
      }],
      "reference" : {
        "reference" : "ValueSet/DIPSVitalSignsObservationPulseMeasurementMethod"
      },
      "name" : "DIPSVitalSignsObservationPulseMeasurementMethod",
      "description" : "Codes representing measurement method",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSVitalSignsObservationSubjectReference.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSVitalSignsObservationSubjectReference"
      },
      "name" : "DIPSVitalSignsObservationSubjectReference",
      "exampleBoolean" : false,
      "groupingId" : "SupportingReferenceProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSVitalSignsPerformerAuthorReference.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSVitalSignsPerformerAuthorReference"
      },
      "name" : "DIPSVitalSignsPerformerAuthorReference",
      "description" : "DIPS profile for Author",
      "exampleBoolean" : false,
      "groupingId" : "SupportingReferenceProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DocumentReference"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DocumentReference-docref-dictated-duration-example.html"
      }],
      "reference" : {
        "reference" : "DocumentReference/docref-dictated-duration-example"
      },
      "name" : "docref-dictated-duration-example",
      "description" : "Test R4 Dictation 1",
      "exampleCanonical" : "http://dips.no/fhir/StructureDefinition/DIPSR4DocumentReference"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DocumentReference"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DocumentReference-docref-dictation-section-example.html"
      }],
      "reference" : {
        "reference" : "DocumentReference/docref-dictation-section-example"
      },
      "name" : "docref-dictation-section-example",
      "description" : "Daglig notat",
      "exampleCanonical" : "http://dips.no/fhir/StructureDefinition/DIPSR4DocumentReference"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DocumentReference"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DocumentReference-docRef-pdf-full.html"
      }],
      "reference" : {
        "reference" : "DocumentReference/docRef-pdf-full"
      },
      "name" : "docRef-pdf-full",
      "description" : "Example PDF",
      "exampleCanonical" : "http://dips.no/fhir/StructureDefinition/DIPSR4DocumentReference"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSDocumentReferenceDocumentFormatNamedQuery.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSDocumentReferenceDocumentFormatNamedQuery"
      },
      "name" : "Document Format (named-query URL variant)",
      "description" : "Same as DIPSDocumentReferenceDocumentFormat, under the URL the documenttype / documentTypeandDepartmentid named queries actually emit. Read-only - not recognized on create or update.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSDocRefContextEncounter.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSDocRefContextEncounter"
      },
      "name" : "DocumentReferenceCotextEncounter",
      "description" : "Profile Encountet for DocumentReference.Context.Ecnounter",
      "exampleBoolean" : false,
      "groupingId" : "SupportingReferenceProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSDocRefOrganization.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSDocRefOrganization"
      },
      "name" : "DocumentReferenceOrganization",
      "description" : "Profile for DocumentReference Organization",
      "exampleBoolean" : false,
      "groupingId" : "SupportingReferenceProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-agy1000245-docref.html"
      }],
      "reference" : {
        "reference" : "Encounter/agy1000245-docref"
      },
      "name" : "Encounter details of agy1000245",
      "description" : "Encounter details of agy1000245, profiled as DIPSDocRefContextEncounter",
      "exampleCanonical" : "http://dips.no/fhir/StructureDefinition/DIPSDocRefContextEncounter"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-agy1000245.html"
      }],
      "reference" : {
        "reference" : "Encounter/agy1000245"
      },
      "name" : "Encounter details of agy1000245",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-agy1002679.html"
      }],
      "reference" : {
        "reference" : "Encounter/agy1002679"
      },
      "name" : "Encounter details of agy1002679",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSDocumentReferenceEPRGroupNamedQuery.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSDocumentReferenceEPRGroupNamedQuery"
      },
      "name" : "EPR Group (named-query URL variant)",
      "description" : "Same as DIPSDocumentReferenceEPRGroup, under the URL the documenttype / documentTypeandDepartmentid named queries actually emit. Read-only - not recognized on create or update.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSDocumentReferenceEventTimeNamedQuery.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSDocumentReferenceEventTimeNamedQuery"
      },
      "name" : "Event Time (named-query URL variant)",
      "description" : "Same as DIPSDocumentReferenceEventTime, under the URL the documenttype / documentTypeandDepartmentid named queries actually emit. Read-only - not recognized on create or update.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-LL355-9-2.80.html"
      }],
      "reference" : {
        "reference" : "ValueSet/LL355-9-2.80"
      },
      "name" : "GCS_1_Eye",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-LL356-7-2.80.html"
      }],
      "reference" : {
        "reference" : "ValueSet/LL356-7-2.80"
      },
      "name" : "GCS_2_Verbal",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-LL357-5-2.80.html"
      }],
      "reference" : {
        "reference" : "ValueSet/LL357-5-2.80"
      },
      "name" : "GCS_3_Motor",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "HealthcareService"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "HealthcareService-HealthcareService-1.html"
      }],
      "reference" : {
        "reference" : "HealthcareService/HealthcareService-1"
      },
      "name" : "HealthcareService-1",
      "exampleCanonical" : "http://dips.no/fhir/R4/StructureDefinition/DIPSHealthcareService"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "HealthcareService"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "HealthcareService-HealthcareService-Emergency-Room.html"
      }],
      "reference" : {
        "reference" : "HealthcareService/HealthcareService-Emergency-Room"
      },
      "name" : "HealthcareService-Emergency-Room",
      "exampleCanonical" : "http://dips.no/fhir/R4/StructureDefinition/DIPSHealthcareService"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-HealthPersonallCategoryValueset.html"
      }],
      "reference" : {
        "reference" : "ValueSet/HealthPersonallCategoryValueset"
      },
      "name" : "HealthPersonallCategoryValueset",
      "description" : "Have volven codesystems and rest of the namesystem",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-healthPersonnelSpecialization.html"
      }],
      "reference" : {
        "reference" : "ValueSet/healthPersonnelSpecialization"
      },
      "name" : "healthPersonnelSpecialization",
      "description" : "Have volven codesystems and rest of the namesystem",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSDocumentReferenceHospitalStayIdNamedQuery.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSDocumentReferenceHospitalStayIdNamedQuery"
      },
      "name" : "Hospital Stay Id (named-query URL variant)",
      "description" : "Same as DIPSDocumentReferenceHospitalStayId, under the URL the documenttype / documentTypeandDepartmentid named queries actually emit. Read-only - not recognized on create or update.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-IsSpecialistExtension.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/IsSpecialistExtension"
      },
      "name" : "IsSpecialistExtension",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-IsUpdatedByPopulationRegister.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/IsUpdatedByPopulationRegister"
      },
      "name" : "IsUpdatedByPopulationRegister",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-KithCoding9040ValueSet.html"
      }],
      "reference" : {
        "reference" : "ValueSet/KithCoding9040ValueSet"
      },
      "name" : "KithCoding9040ValueSet",
      "description" : "Value Sets of KithCoding9040ValueSet",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-KithHealthcareServiceTypes.html"
      }],
      "reference" : {
        "reference" : "ValueSet/KithHealthcareServiceTypes"
      },
      "name" : "KithHealthcareServiceTypes",
      "description" : "Value Sets of KithHealthcareServiceTypes",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-LanguageCodes.html"
      }],
      "reference" : {
        "reference" : "ValueSet/LanguageCodes"
      },
      "name" : "LanguageCodes",
      "description" : "Valesets of LanguageCodes",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-languageid.html"
      }],
      "reference" : {
        "reference" : "ValueSet/languageid"
      },
      "name" : "languageid",
      "description" : "Valesets of languageid",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSDocumentReferenceLastChangedByNamedQuery.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSDocumentReferenceLastChangedByNamedQuery"
      },
      "name" : "Last Changed By (named-query URL variant)",
      "description" : "Same as DIPSDocumentReferenceLastChangedBy, under the URL the documenttype / documentTypeandDepartmentid named queries actually emit. Read-only - not recognized on create or update.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-DIPSDocumentReferenceLastUpdatedTimeNamedQuery.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DIPSDocumentReferenceLastUpdatedTimeNamedQuery"
      },
      "name" : "Last Updated Time (named-query URL variant)",
      "description" : "Same as DIPSDocumentReferenceLastUpdatedTime, under the URL the documenttype / documentTypeandDepartmentid named queries actually emit. Read-only - not recognized on create or update.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-LastOfficialAddressSyncTime.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/LastOfficialAddressSyncTime"
      },
      "name" : "LastOfficialAddressSyncTime",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-LevelOfCareExtension.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/LevelOfCareExtension"
      },
      "name" : "LevelOfCareExtension",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Location"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Location-aea1000021.html"
      }],
      "reference" : {
        "reference" : "Location/aea1000021"
      },
      "name" : "Location details of aea1000021",
      "description" : "Location details of aea1000021",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Location"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Location-afm1.html"
      }],
      "reference" : {
        "reference" : "Location/afm1"
      },
      "name" : "Location details of afm8",
      "description" : "Location details of afm8",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Location"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Location-ahl25.html"
      }],
      "reference" : {
        "reference" : "Location/ahl25"
      },
      "name" : "Location details of ahl25",
      "description" : "Location details of ahl25",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Practitioner"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Practitioner-stf2007723.html"
      }],
      "reference" : {
        "reference" : "Practitioner/stf2007723"
      },
      "name" : "Location details of stf2007723",
      "description" : "Location details of stf2007723",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Location"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Location-Location-Bed-aie1000048.html"
      }],
      "reference" : {
        "reference" : "Location/Location-Bed-aie1000048"
      },
      "name" : "Location-Bed-aie1000048",
      "exampleCanonical" : "http://dips.no/fhir/R4/StructureDefinition/DIPSLocation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Location"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Location-Location-Team-aew1000027.html"
      }],
      "reference" : {
        "reference" : "Location/Location-Team-aew1000027"
      },
      "name" : "Location-Team-aew1000027",
      "exampleCanonical" : "http://dips.no/fhir/R4/StructureDefinition/DIPSLocation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Location"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Location-Location-Ward-ahl1000139.html"
      }],
      "reference" : {
        "reference" : "Location/Location-Ward-ahl1000139"
      },
      "name" : "Location-Ward-ahl1000139",
      "exampleCanonical" : "http://dips.no/fhir/R4/StructureDefinition/DIPSLocation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-LocationAddressId.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/LocationAddressId"
      },
      "name" : "LocationAddressId",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-LocationExtension.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/LocationExtension"
      },
      "name" : "LocationExtension",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-LocationLabLocalizationId.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/LocationLabLocalizationId"
      },
      "name" : "LocationLabLocalizationId",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-LocationTypeCodeId.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/LocationTypeCodeId"
      },
      "name" : "LocationTypeCodeId",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-LocationTypeId.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/LocationTypeId"
      },
      "name" : "LocationTypeId",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-LocationTypes.html"
      }],
      "reference" : {
        "reference" : "ValueSet/LocationTypes"
      },
      "name" : "LocationTypes",
      "description" : "Valesets of Location Types",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-LocationValidPeriod.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/LocationValidPeriod"
      },
      "name" : "LocationValidPeriod",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-LocationWorkplaceLocalizationId.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/LocationWorkplaceLocalizationId"
      },
      "name" : "LocationWorkplaceLocalizationId",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-MunicipalityCode.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/MunicipalityCode"
      },
      "name" : "MunicipalityCode",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-MustOccurBefore.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/MustOccurBefore"
      },
      "name" : "MustOccurBefore",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-no-blood-pressure-create.html"
      }],
      "reference" : {
        "reference" : "Observation/no-blood-pressure-create"
      },
      "name" : "no-blood-pressure-create",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-no-body-height-create.html"
      }],
      "reference" : {
        "reference" : "Observation/no-body-height-create"
      },
      "name" : "no-body-height-create",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-no-body-temperature-create.html"
      }],
      "reference" : {
        "reference" : "Observation/no-body-temperature-create"
      },
      "name" : "no-body-temperature-create",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-no-body-weight-create.html"
      }],
      "reference" : {
        "reference" : "Observation/no-body-weight-create"
      },
      "name" : "no-body-weight-create",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-no-heart-rate-create.html"
      }],
      "reference" : {
        "reference" : "Observation/no-heart-rate-create"
      },
      "name" : "no-heart-rate-create",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-no-oxygen-saturation-create.html"
      }],
      "reference" : {
        "reference" : "Observation/no-oxygen-saturation-create"
      },
      "name" : "no-oxygen-saturation-create",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-no-pulse-rate.html"
      }],
      "reference" : {
        "reference" : "Observation/no-pulse-rate"
      },
      "name" : "no-pulse-rate",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Observation-no-respiratory-rate-create.html"
      }],
      "reference" : {
        "reference" : "Observation/no-respiratory-rate-create"
      },
      "name" : "no-respiratory-rate-create",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-NprLevelOfCare.html"
      }],
      "reference" : {
        "reference" : "ValueSet/NprLevelOfCare"
      },
      "name" : "NprLevelOfCare",
      "description" : "Have volven codesystems and rest of the namesystem",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-NprLevelOfCareExtension.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/NprLevelOfCareExtension"
      },
      "name" : "NprLevelOfCareExtension",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Organization-afa1000061.html"
      }],
      "reference" : {
        "reference" : "Organization/afa1000061"
      },
      "name" : "Organization details of afa1000061",
      "description" : "Organization details of afa1000061",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Organization-afa22.html"
      }],
      "reference" : {
        "reference" : "Organization/afa22"
      },
      "name" : "Organization details of afa22",
      "description" : "Organization details of afa22",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Organization-afa22-docref.html"
      }],
      "reference" : {
        "reference" : "Organization/afa22-docref"
      },
      "name" : "Organization details of afa22",
      "description" : "Organization details of afa22, as referenced by the DocumentReference examples",
      "exampleCanonical" : "http://dips.no/fhir/StructureDefinition/DIPSDocRefOrganization"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Organization-afa23.html"
      }],
      "reference" : {
        "reference" : "Organization/afa23"
      },
      "name" : "Organization details of afa23",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Organization-ahl1000057.html"
      }],
      "reference" : {
        "reference" : "Organization/ahl1000057"
      },
      "name" : "Organization details of ahl1000057",
      "description" : "Organization details of ahl1000057",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Organization-aks1.html"
      }],
      "reference" : {
        "reference" : "Organization/aks1"
      },
      "name" : "Organization details of aks1",
      "description" : "Organization details of aks1",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Organization-aks1000004.html"
      }],
      "reference" : {
        "reference" : "Organization/aks1000004"
      },
      "name" : "Organization details of aks1000004",
      "description" : "Organization details of aks1000004",
      "exampleCanonical" : "http://dips.no/fhir/R4/StructureDefinition/DIPSOrganization"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Organization-aks1000174.html"
      }],
      "reference" : {
        "reference" : "Organization/aks1000174"
      },
      "name" : "Organization details of aks1000174",
      "description" : "Organization details of aks1000174",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Organization-Organization-aks1.html"
      }],
      "reference" : {
        "reference" : "Organization/Organization-aks1"
      },
      "name" : "Organization-aks1",
      "exampleCanonical" : "http://dips.no/fhir/R4/StructureDefinition/DIPSOrganization"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-OrganizationAccessTypes.html"
      }],
      "reference" : {
        "reference" : "ValueSet/OrganizationAccessTypes"
      },
      "name" : "OrganizationAccessTypes",
      "description" : "Value Sets of AccessTypes",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-OrganizationAddressId.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/OrganizationAddressId"
      },
      "name" : "OrganizationAddressId",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Organization-Organizationaks2.html"
      }],
      "reference" : {
        "reference" : "Organization/Organizationaks2"
      },
      "name" : "Organizationaks2",
      "exampleCanonical" : "http://dips.no/fhir/R4/StructureDefinition/DIPSOrganization"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-OrganizationPaymentCode.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/OrganizationPaymentCode"
      },
      "name" : "OrganizationPaymentCode",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-OrganizationTypeCodeId.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/OrganizationTypeCodeId"
      },
      "name" : "OrganizationTypeCodeId",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-OrganizationTypes.html"
      }],
      "reference" : {
        "reference" : "ValueSet/OrganizationTypes"
      },
      "name" : "OrganizationTypes",
      "description" : "Value Sets of OrganizationTypes",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-OrganizationValidPeriod.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/OrganizationValidPeriod"
      },
      "name" : "OrganizationValidPeriod",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Organization-ahl29.html"
      }],
      "reference" : {
        "reference" : "Organization/ahl29"
      },
      "name" : "Orgnization details of ahl29",
      "description" : "Orgnization details of ahl29",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Organization-aju21.html"
      }],
      "reference" : {
        "reference" : "Organization/aju21"
      },
      "name" : "Orgnization details of aju21",
      "description" : "Orgnization details of aju21",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-PartOfDepartment.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/PartOfDepartment"
      },
      "name" : "PartOfDepartment",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-PartOfSection.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/PartOfSection"
      },
      "name" : "PartOfSection",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-cdp1000063.html"
      }],
      "reference" : {
        "reference" : "Patient/cdp1000063"
      },
      "name" : "Patient details of cdp1000063",
      "description" : "Patient details of cdp1000063",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-cdp1000239.html"
      }],
      "reference" : {
        "reference" : "Patient/cdp1000239"
      },
      "name" : "Patient details of cdp1000239",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-cdp1000240.html"
      }],
      "reference" : {
        "reference" : "Patient/cdp1000240"
      },
      "name" : "Patient details of cdp1000240",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-cdp1000807.html"
      }],
      "reference" : {
        "reference" : "Patient/cdp1000807"
      },
      "name" : "Patient details of cdp1000807",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-cdp1000808.html"
      }],
      "reference" : {
        "reference" : "Patient/cdp1000808"
      },
      "name" : "Patient details of cdp1000808",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-cdp2007860.html"
      }],
      "reference" : {
        "reference" : "Patient/cdp2007860"
      },
      "name" : "Patient details of cdp2007860",
      "description" : "Patient details of cdp2007860",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-cdp2009597.html"
      }],
      "reference" : {
        "reference" : "Patient/cdp2009597"
      },
      "name" : "Patient details of cdp2009597",
      "description" : "Patient details of cdp2009597",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-PlannedContactEndTimeExtension.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/PlannedContactEndTimeExtension"
      },
      "name" : "PlannedContactEndTimeExtension",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "PractitionerRole"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "PractitionerRole-agb103.html"
      }],
      "reference" : {
        "reference" : "PractitionerRole/agb103"
      },
      "name" : "Practioner details of agb103",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "PractitionerRole"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "PractitionerRole-agb104.html"
      }],
      "reference" : {
        "reference" : "PractitionerRole/agb104"
      },
      "name" : "Practioner details of agb104",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "PractitionerRole"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "PractitionerRole-agb113.html"
      }],
      "reference" : {
        "reference" : "PractitionerRole/agb113"
      },
      "name" : "Practioner details of agb113",
      "description" : "Practioner details of agb113",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "PractitionerRole"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "PractitionerRole-agb91.html"
      }],
      "reference" : {
        "reference" : "PractitionerRole/agb91"
      },
      "name" : "PractionerRole details of agb91",
      "description" : "PractionerRole details of agb91",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Practitioner"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Practitioner-Practitioner-stf39.html"
      }],
      "reference" : {
        "reference" : "Practitioner/Practitioner-stf39"
      },
      "name" : "Practitioner-stf39",
      "exampleCanonical" : "http://dips.no/fhir/R4/StructureDefinition/DIPSPractitioner"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "PractitionerRole"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "PractitionerRole-agb1000043.html"
      }],
      "reference" : {
        "reference" : "PractitionerRole/agb1000043"
      },
      "name" : "PractitionerRole details of agb1000043",
      "description" : "PractitionerRole details of agb1000043",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "PractitionerRole"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "PractitionerRole-agb1000456.html"
      }],
      "reference" : {
        "reference" : "PractitionerRole/agb1000456"
      },
      "name" : "PractitionerRole details of agb1000456",
      "description" : "PractitionerRole details of agb1000456",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "PractitionerRole"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "PractitionerRole-agb27.html"
      }],
      "reference" : {
        "reference" : "PractitionerRole/agb27"
      },
      "name" : "PractitionerRole details of agb27",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "PractitionerRole"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "PractitionerRole-agb30.html"
      }],
      "reference" : {
        "reference" : "PractitionerRole/agb30"
      },
      "name" : "PractitionerRole details of agb30",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "PractitionerRole"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "PractitionerRole-agb57.html"
      }],
      "reference" : {
        "reference" : "PractitionerRole/agb57"
      },
      "name" : "PractitionerRole details of agb57",
      "description" : "PractitionerRole details of agb57",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "PractitionerRole"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "PractitionerRole-agb59.html"
      }],
      "reference" : {
        "reference" : "PractitionerRole/agb59"
      },
      "name" : "PractitionerRole details of agb59",
      "description" : "PractitionerRole details of agb59",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "PractitionerRole"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "PractitionerRole-PractitionerRole-agb1000203.html"
      }],
      "reference" : {
        "reference" : "PractitionerRole/PractitionerRole-agb1000203"
      },
      "name" : "PractitionerRole-agb1000203",
      "exampleCanonical" : "http://dips.no/fhir/R4/StructureDefinition/DIPSPractitionerRole"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "PractitionerRole"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "PractitionerRole-PractitionerRole-Physiotherapist.html"
      }],
      "reference" : {
        "reference" : "PractitionerRole/PractitionerRole-Physiotherapist"
      },
      "name" : "PractitionerRole-Physiotherapist",
      "exampleCanonical" : "http://dips.no/fhir/R4/StructureDefinition/DIPSPractitionerRole"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-ReferredBy.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ReferredBy"
      },
      "name" : "ReferredBy",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-relatedperson-relationshiptype.html"
      }],
      "reference" : {
        "reference" : "ValueSet/relatedperson-relationshiptype"
      },
      "name" : "relatedperson-relationshiptype",
      "description" : "Valesets of Guardian",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-Reminder.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/Reminder"
      },
      "name" : "Reminder",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-requesterSigningStatus.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/requesterSigningStatus"
      },
      "name" : "requesterSigningStatus",
      "description" : "DIPS: describes if the lab result has been signed by the requester in DIPS",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-SectionExtension.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/SectionExtension"
      },
      "name" : "SectionExtension",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-SectionProfessionCodeId.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/SectionProfessionCodeId"
      },
      "name" : "SectionProfessionCodeId",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-SelfBookingSlot.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/SelfBookingSlot"
      },
      "name" : "SelfBookingSlot",
      "exampleBoolean" : false,
      "groupingId" : "SlotProfiles"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ServiceRequest"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ServiceRequest-ahr1003778.html"
      }],
      "reference" : {
        "reference" : "ServiceRequest/ahr1003778"
      },
      "name" : "ServiceRequest details of ahr1003778",
      "description" : "ServiceRequest details of ahr1003778",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-DIPSVitalSignsObservationConsciousness.html"
      }],
      "reference" : {
        "reference" : "ValueSet/DIPSVitalSignsObservationConsciousness"
      },
      "name" : "SNOMED CT Consciousness Structures",
      "description" : "Codes representing consciousness",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TeamTypeId.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TeamTypeId"
      },
      "name" : "TeamTypeId",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TerminationExtension.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TerminationExtension"
      },
      "name" : "TerminationExtension",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-TextResultObservation.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/TextResultObservation"
      },
      "name" : "TextResultObservation",
      "description" : "DIPS: textual rendering of a lab result that is otherwise carried as a Quantity.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-VideoUrl.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/VideoUrl"
      },
      "name" : "VideoUrl",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-WardExtension.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/WardExtension"
      },
      "name" : "WardExtension",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-WardTypeCodeId.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/WardTypeCodeId"
      },
      "name" : "WardTypeCodeId",
      "exampleBoolean" : false
    }],
    "page" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
        "valueUrl" : "toc.html"
      }],
      "nameUrl" : "toc.html",
      "title" : "Table of Contents",
      "generation" : "html",
      "page" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "index.html"
        }],
        "nameUrl" : "index.html",
        "title" : "Home",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "changes.html"
        }],
        "nameUrl" : "changes.html",
        "title" : "Changes",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "documentation.html"
        }],
        "nameUrl" : "documentation.html",
        "title" : "Documentation",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "download.html"
        }],
        "nameUrl" : "download.html",
        "title" : "Download",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "implementation-status.html"
        }],
        "nameUrl" : "implementation-status.html",
        "title" : "Implementation Status",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "reference-diagrams.html"
        }],
        "nameUrl" : "reference-diagrams.html",
        "title" : "Reference Diagrams",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "resourcelist.html"
        }],
        "nameUrl" : "resourcelist.html",
        "title" : "Resourcelist",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "resourcelist-appointment.html"
        }],
        "nameUrl" : "resourcelist-appointment.html",
        "title" : "Resourcelist Appointment",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "resourcelist-capabilitystatement.html"
        }],
        "nameUrl" : "resourcelist-capabilitystatement.html",
        "title" : "Resourcelist Capabilitystatement",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "resourcelist-codesystem.html"
        }],
        "nameUrl" : "resourcelist-codesystem.html",
        "title" : "Resourcelist Codesystem",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "resourcelist-condition.html"
        }],
        "nameUrl" : "resourcelist-condition.html",
        "title" : "Resourcelist Condition",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "resourcelist-diagnosticreport.html"
        }],
        "nameUrl" : "resourcelist-diagnosticreport.html",
        "title" : "Resourcelist Diagnosticreport",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "resourcelist-documentreference.html"
        }],
        "nameUrl" : "resourcelist-documentreference.html",
        "title" : "Resourcelist Documentreference",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "resourcelist-encounter.html"
        }],
        "nameUrl" : "resourcelist-encounter.html",
        "title" : "Resourcelist Encounter",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "resourcelist-episodeofcare.html"
        }],
        "nameUrl" : "resourcelist-episodeofcare.html",
        "title" : "Resourcelist Episodeofcare",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "resourcelist-healthcareservice.html"
        }],
        "nameUrl" : "resourcelist-healthcareservice.html",
        "title" : "Resourcelist Healthcareservice",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "resourcelist-location.html"
        }],
        "nameUrl" : "resourcelist-location.html",
        "title" : "Resourcelist Location",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "resourcelist-not-profiled.html"
        }],
        "nameUrl" : "resourcelist-not-profiled.html",
        "title" : "Resourcelist Not Profiled",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "resourcelist-observation.html"
        }],
        "nameUrl" : "resourcelist-observation.html",
        "title" : "Resourcelist Observation",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "resourcelist-organization.html"
        }],
        "nameUrl" : "resourcelist-organization.html",
        "title" : "Resourcelist Organization",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "resourcelist-patient.html"
        }],
        "nameUrl" : "resourcelist-patient.html",
        "title" : "Resourcelist Patient",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "resourcelist-person.html"
        }],
        "nameUrl" : "resourcelist-person.html",
        "title" : "Resourcelist Person",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "resourcelist-practitioner.html"
        }],
        "nameUrl" : "resourcelist-practitioner.html",
        "title" : "Resourcelist Practitioner",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "resourcelist-practitionerrole.html"
        }],
        "nameUrl" : "resourcelist-practitionerrole.html",
        "title" : "Resourcelist Practitionerrole",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "resourcelist-procedure.html"
        }],
        "nameUrl" : "resourcelist-procedure.html",
        "title" : "Resourcelist Procedure",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "resourcelist-relatedperson.html"
        }],
        "nameUrl" : "resourcelist-relatedperson.html",
        "title" : "Resourcelist Relatedperson",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "resourcelist-schedule.html"
        }],
        "nameUrl" : "resourcelist-schedule.html",
        "title" : "Resourcelist Schedule",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "resourcelist-servicerequest.html"
        }],
        "nameUrl" : "resourcelist-servicerequest.html",
        "title" : "Resourcelist Servicerequest",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "resourcelist-slot.html"
        }],
        "nameUrl" : "resourcelist-slot.html",
        "title" : "Resourcelist Slot",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "resourcelist-valueset.html"
        }],
        "nameUrl" : "resourcelist-valueset.html",
        "title" : "Resourcelist Valueset",
        "generation" : "markdown"
      }]
    },
    "parameter" : [{
      "code" : "path-resource",
      "value" : "input/capabilities"
    },
    {
      "code" : "path-resource",
      "value" : "input/examples"
    },
    {
      "code" : "path-resource",
      "value" : "input/extensions"
    },
    {
      "code" : "path-resource",
      "value" : "input/models"
    },
    {
      "code" : "path-resource",
      "value" : "input/operations"
    },
    {
      "code" : "path-resource",
      "value" : "input/profiles"
    },
    {
      "code" : "path-resource",
      "value" : "input/resources"
    },
    {
      "code" : "path-resource",
      "value" : "input/vocabulary"
    },
    {
      "code" : "path-resource",
      "value" : "input/maps"
    },
    {
      "code" : "path-resource",
      "value" : "input/testing"
    },
    {
      "code" : "path-resource",
      "value" : "input/history"
    },
    {
      "code" : "path-resource",
      "value" : "fsh-generated/resources"
    },
    {
      "code" : "path-pages",
      "value" : "template/config"
    },
    {
      "code" : "path-pages",
      "value" : "input/images"
    },
    {
      "code" : "path-tx-cache",
      "value" : "input-cache/txcache"
    }]
  }
}

```
