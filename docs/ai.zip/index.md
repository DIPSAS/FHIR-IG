# Home - DIPS Core Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://dips.no/fhir/R4/ImplementationGuide/dips.fhir.no.core | *Version*:0.1.0 |
| Draft as of 2026-09-08 | *Computable Name*:DIPSCore |

# DIPS Core Implementation Guide

This Implementation Guide describes the FHIR R4 profiles, extensions, value sets, code systems and examples used by DIPS AS to expose core clinical and administrative data — such as Patient, Person, Organization, Location, Practitioner, PractitionerRole, RelatedPerson, HealthcareService, Encounter and vital sign observations — through the DIPS FHIR R4 API.

The profiles in this guide build on [hl7.fhir.no.basis](https://simplifier.net/HL7Norway/), the Norwegian national base profiles, adding DIPS-specific extensions and constraints required to represent data from the DIPS core system.

### Intended audience

This guide is intended for developers and integrators building or consuming integrations against the DIPS FHIR R4 API. See the [Documentation](documentation.md) page for details on authentication and how to call the API, [Artifacts](artifacts.md) for the full list of profiles, extensions, value sets and code systems, and [Download](download.md) for how to obtain the packaged IG.

### Scope

* **Demographics**: Patient, Person, RelatedPerson
* **Organizational structure**: Organization, Location, HealthcareService
* **Practitioners**: Practitioner, PractitionerRole
* **Clinical**: Encounter, Appointment, DocumentReference, and Norwegian vital sign Observation profiles (blood pressure, body height/weight/temperature/mass index, heart rate, oxygen saturation, respiration rate, consciousness, NEWS2 and qSOFA scores, GCS)

