# noImpl-respiratory-rate-create - DIPS Core Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **noImpl-respiratory-rate-create**

## Example Observation: noImpl-respiratory-rate-create



## Resource Content

```json
{
  "resourceType" : "Observation",
  "id" : "noImpl-respiratory-rate-create",
  "meta" : {
    "versionId" : "0",
    "lastUpdated" : "2014-01-30T22:35:23+11:00",
    "source" : "NoImpl",
    "profile" : ["http://dips.no/fhir/R4/StructureDefinition/NoImplVitalSignsObservationRespirationRate"]
  },
  "extension" : [{
    "url" : "http://dips.no/fhir/R4/StructureDefinition/NoImplVitalSignsObservationRespirationRegularity",
    "valueCoding" : {
      "system" : "http://snomed.info/sct",
      "code" : "276888009",
      "display" : "Regelmessig"
    }
  },
  {
    "url" : "http://dips.no/fhir/R4/StructureDefinition/NoImplVitalSignsObservationRespirationDepth",
    "valueCoding" : {
      "system" : "http://snomed.info/sct",
      "code" : "301284009",
      "display" : "Normal"
    }
  }],
  "identifier" : [{
    "system" : "http://dips.no/fhir/namingsystem/dips-RelativeEhrUri",
    "value" : "ehr:compositions/6c41D37f-f173-45d6-8504-17c40454b9ee::default::1/content[openEHR-EHR-OBSERVATION.respiration.v2 and name/value='Respirasjonsfrekvens']"
  },
  {
    "system" : "http://dips.no/fhir/namingsystem/dips-ObservationId",
    "value" : "dips-respiratory-rate-create"
  },
  {
    "system" : "http://dips.no/fhir/namingsystem/dips-VersionIndependentId",
    "value" : "bd96cd32-3bdb-f448-9d65-265828cae8c8"
  },
  {
    "system" : "http://dips.no/fhir/namingsystem/externalId",
    "value" : "testBPexternalId1"
  }],
  "status" : "final",
  "category" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
      "code" : "vital-signs",
      "display" : "Vital Signs"
    }]
  }],
  "code" : {
    "coding" : [{
      "system" : "http://loinc.org",
      "code" : "9279-1",
      "display" : "Respiratory rate"
    },
    {
      "system" : "http://snomed.info/sct",
      "code" : "271625008",
      "display" : "Rate of spontaneous respiration (observable entity)"
    }]
  },
  "subject" : {
    "reference" : "Patient/cdp2007964",
    "identifier" : {
      "system" : "http://dips.no/fhir/namingsystem/dips-patientid",
      "value" : "1002679"
    }
  },
  "encounter" : {
    "reference" : "Encounter/agy1000245",
    "identifier" : {
      "system" : "http://dips.no/fhir/namingsystem/dips-omsorgsepisodeid",
      "value" : "1000245"
    }
  },
  "effectiveDateTime" : "2021-10-25T09:30:33+05:30",
  "performer" : [{
    "reference" : "PractitionerRole/agb1000204",
    "identifier" : {
      "system" : "urn:oid:1.3.6.1.4.1.9038.51.1",
      "value" : "1000204"
    }
  },
  {
    "reference" : "Organization/Organizationaks2",
    "identifier" : {
      "system" : "urn:oid:1.3.6.1.4.1.9038.70.1",
      "value" : "2"
    }
  }],
  "valueQuantity" : {
    "value" : 23,
    "unit" : "/min",
    "system" : "http://unitsofmeasure.org",
    "code" : "/min"
  },
  "referenceRange" : [{
    "low" : {
      "value" : 12,
      "unit" : "/min"
    },
    "high" : {
      "value" : 20,
      "unit" : "/min"
    }
  }]
}

```
