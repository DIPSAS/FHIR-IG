# Encounter details of agy1002679 - DIPS Core Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Encounter details of agy1002679**

## Example Encounter: Encounter details of agy1002679

**identifier**: `http://dips.no/fhir/namingsystem/dips-omsorgsepisodeid`/agy1002679

**status**: Arrived

**class**: [ActCode: AMB](http://terminology.hl7.org/7.5.0/CodeSystem-v3-ActCode.html#v3-ActCode-AMB) (ambulatory)



## Resource Content

```json
{
  "resourceType" : "Encounter",
  "id" : "agy1002679",
  "identifier" : [{
    "system" : "http://dips.no/fhir/namingsystem/dips-omsorgsepisodeid",
    "value" : "agy1002679"
  }],
  "status" : "arrived",
  "class" : {
    "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
    "code" : "AMB"
  }
}

```
