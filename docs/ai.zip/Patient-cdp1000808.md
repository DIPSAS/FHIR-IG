# Patient details of cdp1000808 - DIPS Core Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Patient details of cdp1000808**

## Example Patient: Patient details of cdp1000808

Anonymous Patient (no stated gender), DoB Unknown ( urn:oid:2.16.578.1.12.4.1.4.1#Foedselsnummer#1000808)

-------



## Resource Content

```json
{
  "resourceType" : "Patient",
  "id" : "cdp1000808",
  "identifier" : [{
    "system" : "urn:oid:2.16.578.1.12.4.1.4.1",
    "value" : "1000808"
  }]
}

```
