# Organization details of afa23 - DIPS Core Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Organization details of afa23**

## Example Organization: Organization details of afa23

Unnamed Organization (urn:oid:1.3.6.1.4.1.9038.70.3#23)

-------



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "afa23",
  "identifier" : [{
    "system" : "urn:oid:1.3.6.1.4.1.9038.70.3",
    "value" : "23"
  }]
}

```
