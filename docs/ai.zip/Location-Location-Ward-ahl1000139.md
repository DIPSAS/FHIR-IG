# Location-Ward-ahl1000139 - DIPS Core Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Location-Ward-ahl1000139**

## Example Location: Location-Ward-ahl1000139

Profiles: [DIPSLocation](StructureDefinition-DIPSLocation.md), [no-basis-Location](https://simplifier.net/resolve?scope=hl7.fhir.no.domain.vitalsigns@0.9.74&canonical=http://hl7.no/fhir/StructureDefinition/no-basis-Location)

Tag: 

Security Label: 

Kirurgisk Post 2, Sd (0, Post) (urn:oid:1.3.6.1.4.1.9038.70.4#1000139 (use: official))

-------

| | | | |
| :--- | :--- | :--- | :--- |
| Status: | Active | Mode: | Instance |
| Form: | Ward | | |
| Type: | * 0
* Post
 | | |
| Address: | (work) | | |
| Other Id: | `http://dips.no/fhir/namingsystem/dips-wardshortname`/K2 Sd (use: official) | | |



## Resource Content

```json
{
  "resourceType" : "Location",
  "id" : "Location-Ward-ahl1000139",
  "meta" : {
    "profile" : ["http://dips.no/fhir/R4/StructureDefinition/DIPSLocation",
    "http://hl7.no/fhir/StructureDefinition/no-basis-Location"],
    "security" : [{
      "system" : "http://dips.no/fhir/InternalSecurityAccess",
      "code" : "A",
      "display" : "ALL"
    }],
    "tag" : [{
      "system" : "http://dips.no/fhir/namingsystem/locationsource",
      "code" : "ward"
    }]
  },
  "identifier" : [{
    "use" : "official",
    "system" : "urn:oid:1.3.6.1.4.1.9038.70.4",
    "value" : "1000139"
  },
  {
    "use" : "official",
    "system" : "http://dips.no/fhir/namingsystem/dips-wardshortname",
    "value" : "K2 Sd"
  }],
  "status" : "active",
  "name" : "Kirurgisk Post 2, Sd",
  "mode" : "instance",
  "type" : [{
    "coding" : [{
      "system" : "http://dips.no/fhir/namingsystem/dips-disasterward",
      "code" : "0"
    }]
  },
  {
    "coding" : [{
      "system" : "http://dips.no/fhir/ValueSet/locationtoplevel",
      "code" : "08",
      "display" : "Post"
    }]
  }],
  "address" : {
    "extension" : [{
      "url" : "http://dips.no/fhir/R4/StructureDefinition/LocationAddressId",
      "valueIdentifier" : {
        "use" : "official",
        "system" : "http://dips.no/fhir/namingsystem/dips-addressid",
        "value" : "1001177"
      }
    }],
    "use" : "work",
    "type" : "physical"
  },
  "physicalType" : {
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/location-physical-type",
      "code" : "wa",
      "display" : "Ward"
    }]
  }
}

```
