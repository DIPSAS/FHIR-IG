# DIPSDocumentReferenceSubject - DIPS Core Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **DIPSDocumentReferenceSubject**

## Resource Profile: DIPSDocumentReferenceSubject 

| | |
| :--- | :--- |
| *Official URL*:http://dips.no/fhir/StructureDefinition/DIPSDocumentReferenceSubject | *Version*:0.1.0 |
| Draft as of 2026-11-10 | *Computable Name*:DIPSDocumentReferenceSubject |

 
Patient Profile of DocumentReference 

**Usages:**

* Refer to this Profile: [DIPSR4DocumentReference](StructureDefinition-DIPSR4DocumentReference.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/dips.fhir.no.core|current/StructureDefinition/StructureDefinition-DIPSDocumentReferenceSubject.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-DIPSDocumentReferenceSubject.csv), [Excel](StructureDefinition-DIPSDocumentReferenceSubject.xlsx), [Schematron](StructureDefinition-DIPSDocumentReferenceSubject.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "DIPSDocumentReferenceSubject",
  "url" : "http://dips.no/fhir/StructureDefinition/DIPSDocumentReferenceSubject",
  "version" : "0.1.0",
  "name" : "DIPSDocumentReferenceSubject",
  "title" : "DIPSDocumentReferenceSubject",
  "status" : "draft",
  "date" : "2026-11-10T08:48:38+00:00",
  "publisher" : "DIPS AS",
  "contact" : [{
    "name" : "Lars-Andreas Nystad",
    "telecom" : [{
      "system" : "email",
      "value" : "mailto:lan@dips.no",
      "use" : "work"
    }]
  }],
  "description" : "Patient Profile of DocumentReference",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "NO",
      "display" : "Norway"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "cda",
    "uri" : "http://hl7.org/v3/cda",
    "name" : "CDA (R2)"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "loinc",
    "uri" : "http://loinc.org",
    "name" : "LOINC code for the element"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Patient",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Patient",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Patient",
      "path" : "Patient"
    },
    {
      "id" : "Patient.identifier",
      "path" : "Patient.identifier",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "system"
        }],
        "rules" : "open"
      },
      "min" : 1
    },
    {
      "id" : "Patient.identifier:FNR",
      "path" : "Patient.identifier",
      "sliceName" : "FNR",
      "short" : "Norwegian national identity number",
      "definition" : "Norwegian national identity number (\"Fødselsnummer\").",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "Patient.identifier:FNR.use",
      "path" : "Patient.identifier.use",
      "max" : "0"
    },
    {
      "id" : "Patient.identifier:FNR.type",
      "path" : "Patient.identifier.type",
      "max" : "0"
    },
    {
      "id" : "Patient.identifier:FNR.system",
      "path" : "Patient.identifier.system",
      "min" : 1,
      "fixedUri" : "urn:oid:2.16.578.1.12.4.1.4.1"
    },
    {
      "id" : "Patient.identifier:FNR.value",
      "path" : "Patient.identifier.value",
      "min" : 1
    },
    {
      "id" : "Patient.identifier:FNR.period",
      "path" : "Patient.identifier.period",
      "max" : "0"
    },
    {
      "id" : "Patient.identifier:FNR.assigner",
      "path" : "Patient.identifier.assigner",
      "max" : "0"
    },
    {
      "id" : "Patient.identifier:DNR",
      "path" : "Patient.identifier",
      "sliceName" : "DNR",
      "short" : "D-nummer",
      "definition" : "Temporary Norwegian identity number assigned to foreigners living in Norway (\"D-nummer\").",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "Patient.identifier:DNR.use",
      "path" : "Patient.identifier.use",
      "max" : "0"
    },
    {
      "id" : "Patient.identifier:DNR.type",
      "path" : "Patient.identifier.type",
      "max" : "0"
    },
    {
      "id" : "Patient.identifier:DNR.system",
      "path" : "Patient.identifier.system",
      "min" : 1,
      "fixedUri" : "urn:oid:2.16.578.1.12.4.1.4.2"
    },
    {
      "id" : "Patient.identifier:DNR.value",
      "path" : "Patient.identifier.value",
      "min" : 1
    },
    {
      "id" : "Patient.identifier:DNR.period",
      "path" : "Patient.identifier.period",
      "max" : "0"
    },
    {
      "id" : "Patient.identifier:DNR.assigner",
      "path" : "Patient.identifier.assigner",
      "max" : "0"
    },
    {
      "id" : "Patient.identifier:patientId",
      "path" : "Patient.identifier",
      "sliceName" : "patientId",
      "short" : "Indicates a patient identifier by the internal patient record ID.",
      "definition" : "Indicates a patient identifier by the internal patient record ID.",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "Patient.identifier:patientId.use",
      "path" : "Patient.identifier.use",
      "max" : "0"
    },
    {
      "id" : "Patient.identifier:patientId.type",
      "path" : "Patient.identifier.type",
      "max" : "0"
    },
    {
      "id" : "Patient.identifier:patientId.system",
      "path" : "Patient.identifier.system",
      "min" : 1,
      "fixedUri" : "http://dips.no/fhir/namingsystem/dips-patientid"
    },
    {
      "id" : "Patient.identifier:patientId.value",
      "path" : "Patient.identifier.value",
      "min" : 1
    },
    {
      "id" : "Patient.identifier:patientId.period",
      "path" : "Patient.identifier.period",
      "max" : "0"
    },
    {
      "id" : "Patient.identifier:patientId.assigner",
      "path" : "Patient.identifier.assigner",
      "max" : "0"
    },
    {
      "id" : "Patient.identifier:FHN",
      "path" : "Patient.identifier",
      "sliceName" : "FHN",
      "short" : "Temporary identity number (\"Hjelpenummer\"),",
      "definition" : "Temporary identity number (\"Hjelpenummer\"),commonly used when the patient does not have a national identity number or D-number, or if it is unknown.",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "Patient.identifier:FHN.use",
      "path" : "Patient.identifier.use",
      "max" : "0"
    },
    {
      "id" : "Patient.identifier:FHN.type",
      "path" : "Patient.identifier.type",
      "max" : "0"
    },
    {
      "id" : "Patient.identifier:FHN.system",
      "path" : "Patient.identifier.system",
      "min" : 1,
      "fixedUri" : "urn:oid:2.16.578.1.12.4.1.4.3"
    },
    {
      "id" : "Patient.identifier:FHN.value",
      "path" : "Patient.identifier.value",
      "min" : 1
    },
    {
      "id" : "Patient.identifier:FHN.period",
      "path" : "Patient.identifier.period",
      "max" : "0"
    },
    {
      "id" : "Patient.identifier:FHN.assigner",
      "path" : "Patient.identifier.assigner",
      "max" : "0"
    }]
  }
}

```
