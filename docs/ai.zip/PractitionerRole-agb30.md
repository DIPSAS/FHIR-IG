# PractitionerRole details of agb30 - DIPS Core Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **PractitionerRole details of agb30**

## Example PractitionerRole: PractitionerRole details of agb30

**identifier**: `urn:oid:1.3.6.1.4.1.9038.51.1`/30



## Resource Content

```json
{
  "resourceType" : "PractitionerRole",
  "id" : "agb30",
  "identifier" : [{
    "system" : "urn:oid:1.3.6.1.4.1.9038.51.1",
    "value" : "30"
  }]
}

```
