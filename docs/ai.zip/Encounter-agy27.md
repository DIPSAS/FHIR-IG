# agy27 - DIPS Core Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **agy27**

## Example Encounter: agy27



## Resource Content

```json
{
  "resourceType" : "Encounter",
  "id" : "agy27",
  "meta" : {
    "profile" : ["http://dips.no/fhir/R4/StructureDefinition/DIPSR4Encounter"],
    "security" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v3-Confidentiality",
      "code" : "N"
    }],
    "tag" : [{
      "system" : "http://dips.no/fhir/namingsystem/encountersource",
      "code" : "episodeofcare"
    }]
  },
  "contained" : [{
    "resourceType" : "Encounter",
    "id" : "amw38",
    "meta" : {
      "profile" : ["http://dips.no/fhir/R4/StructureDefinition/DIPSHospitalStayEncounter"],
      "tag" : [{
        "system" : "http://dips.no/fhir/namingsystem/encountersource",
        "code" : "hospitalstay"
      }]
    },
    "identifier" : [{
      "system" : "http://dips.no/fhir/namingsystem/dips-hospitalstayid",
      "value" : "38"
    }],
    "status" : "in-progress",
    "class" : {
      "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
      "code" : "IMP",
      "display" : "inpatient encounter"
    }
  }],
  "extension" : [{
    "url" : "http://dips.no/fhir/R4/StructureDefinition/ReferredBy",
    "valueReference" : {
      "reference" : "PractitionerRole/agb61",
      "identifier" : {
        "system" : "urn:oid:1.3.6.1.4.1.9038.51.1",
        "value" : "61"
      }
    }
  },
  {
    "url" : "http://dips.no/fhir/R4/StructureDefinition/TerminationExtension",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "http://dips.no/fhir/namingsystem/dips-terminationcodeid",
        "code" : "315",
        "display" : "Tilh. annet sykehus"
      },
      {
        "system" : "http://dips.no/fhir/namingsystem/dips-terminationcode",
        "code" : "TA",
        "display" : "Tilh. annet sykehus"
      }]
    }
  },
  {
    "url" : "http://dips.no/fhir/R4/StructureDefinition/PlannedContactEndTimeExtension",
    "valueDateTime" : "2003-11-01T00:00:00+00:00"
  },
  {
    "url" : "http://dips.no/fhir/R4/StructureDefinition/Department",
    "valueReference" : {
      "reference" : "Organization/afa22",
      "identifier" : {
        "system" : "urn:oid:1.3.6.1.4.1.9038.70.3",
        "value" : "22"
      },
      "display" : "Kirurgisk avdeling"
    }
  },
  {
    "url" : "http://dips.no/fhir/R4/StructureDefinition/DipsLocationExtension",
    "valueReference" : {
      "reference" : "Location/aea1000021",
      "identifier" : {
        "system" : "urn:oid:1.3.6.1.4.1.9038.70.6",
        "value" : "1000021"
      },
      "display" : "Testsykehuset bygg A"
    }
  }],
  "identifier" : [{
    "system" : "http://dips.no/fhir/namingsystem/dips-omsorgsepisodeid",
    "value" : "27"
  },
  {
    "system" : "http://dips.no/fhir/namingsystem/dips-plannedcontactid",
    "value" : "38"
  },
  {
    "system" : "http://dips.no/fhir/namingsystem/dips-bookingid",
    "value" : "62377f66-377e-9148-9db2-55a920ffb907"
  }],
  "status" : "finished",
  "class" : {
    "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
    "code" : "IMP",
    "display" : "inpatient encounter"
  },
  "type" : [{
    "id" : "ContactType",
    "coding" : [{
      "system" : "http://dips.no/fhir/namingsystem/dips-contacttypecodeid",
      "code" : "106800",
      "display" : "Heldøgn"
    },
    {
      "system" : "urn:oid:2.16.578.1.12.4.1.1.8240",
      "code" : "01",
      "display" : "Heldøgn"
    }]
  }],
  "subject" : {
    "reference" : "Patient/cdp138",
    "identifier" : {
      "system" : "http://dips.no/fhir/namingsystem/dips-patientid",
      "value" : "138"
    },
    "display" : "Spelemann (Testplan - Journal), Per"
  },
  "basedOn" : [{
    "reference" : "ServiceRequest/agc48",
    "identifier" : {
      "system" : "http://dips.no/fhir/namingsystem/dips-referralid",
      "value" : "48"
    }
  }],
  "participant" : [{
    "type" : [{
      "coding" : [{
        "system" : "http://dips.no/fhir/encounter/participanttype",
        "code" : "attending-doctor"
      }]
    }],
    "individual" : {
      "reference" : "PractitionerRole/agb42",
      "identifier" : {
        "system" : "urn:oid:1.3.6.1.4.1.9038.51.1",
        "value" : "42"
      }
    }
  }],
  "appointment" : [{
    "reference" : "Appointment/ahi38",
    "identifier" : {
      "system" : "http://dips.no/fhir/namingsystem/dips-plannedcontactid",
      "value" : "38"
    }
  }],
  "period" : {
    "start" : "2003-10-29T14:18:53+00:00",
    "end" : "2003-11-01T15:21:42+00:00"
  },
  "reasonCode" : [{
    "text" : "Kronsik bronkitt"
  }],
  "location" : [{
    "location" : {
      "reference" : "Location/ahl25",
      "identifier" : {
        "system" : "urn:oid:2.16.578.1.12.4.1.4.102",
        "value" : "10068"
      },
      "display" : "Intensiv post 1"
    },
    "status" : "active",
    "physicalType" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/location-physical-type",
        "code" : "wa",
        "display" : "Ward"
      }]
    },
    "period" : {
      "start" : "2003-10-29T14:18:53+00:00",
      "end" : "2003-11-01T15:21:42+00:00"
    }
  }],
  "serviceProvider" : {
    "reference" : "Organization/afa22",
    "identifier" : {
      "system" : "urn:oid:2.16.578.1.12.4.1.4.102",
      "value" : "10013"
    },
    "display" : "Kirurgisk avdeling | Testsykehuset DIPS"
  },
  "partOf" : {
    "reference" : "#amw38"
  }
}

```
