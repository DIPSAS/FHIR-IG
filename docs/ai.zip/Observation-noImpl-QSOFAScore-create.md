# noImpl-QSOFAScore-create - DIPS Core Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **noImpl-QSOFAScore-create**

## Example Observation: noImpl-QSOFAScore-create



## Resource Content

```json
{
  "resourceType" : "Observation",
  "id" : "noImpl-QSOFAScore-create",
  "meta" : {
    "versionId" : "0",
    "lastUpdated" : "2014-01-30T11:35:23+00:00",
    "source" : "NoImpl",
    "profile" : ["http://dips.no/fhir/R4/StructureDefinition/NoImplVitalSignsObservationQSOFAScore"]
  },
  "identifier" : [{
    "system" : "http://dips.no/fhir/namingsystem/dips-RelativeEhrUri",
    "value" : "ehr:compositions/6c41D37f-f173-45d6-8504-17c40454b9ee::default::1/content[openEHR-EHR-OBSERVATION.news2.v1 and name/value='NEWS2-Basic-Vitals']"
  },
  {
    "system" : "http://dips.no/fhir/namingsystem/dips-ObservationId",
    "value" : "dfdcd132-f0c0-e84a-a9b0-937bcb93c008"
  },
  {
    "system" : "http://dips.no/fhir/namingsystem/dips-VersionIndependentId",
    "value" : "bd96cd32-3bdb-f448-9d65-265828cae8c8"
  },
  {
    "system" : "http://dips.no/fhir/namingsystem/externalId",
    "value" : "testBPexternalId1"
  }],
  "status" : "final",
  "category" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
      "code" : "survey",
      "display" : "Survey"
    }]
  }],
  "code" : {
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "63451000122107",
      "display" : "qSOFA score (observable entity)"
    }]
  },
  "subject" : {
    "reference" : "Patient/cdp2007964",
    "identifier" : {
      "system" : "http://dips.no/fhir/namingsystem/dips-patientid",
      "value" : "1002679"
    }
  },
  "effectiveDateTime" : "2021-10-25T09:30:33+05:30",
  "performer" : [{
    "reference" : "PractitionerRole/agb1000204",
    "identifier" : {
      "system" : "urn:oid:1.3.6.1.4.1.9038.51.1",
      "value" : "1000204"
    }
  },
  {
    "reference" : "Organization/Organizationaks2",
    "identifier" : {
      "system" : "urn:oid:1.3.6.1.4.1.9038.70.1",
      "value" : "2"
    }
  }],
  "valueQuantity" : {
    "value" : 3,
    "unit" : "ScoreOf",
    "system" : "http://unitsofmeasure.org",
    "code" : "{ScoreOf}"
  },
  "derivedFrom" : [{
    "reference" : "Observation/noImpl-respiratory-rate-create"
  },
  {
    "reference" : "Observation/noimpl-bloodpressure-instance"
  },
  {
    "reference" : "Observation/noImpl-consciousness-create"
  }],
  "component" : [{
    "code" : {
      "coding" : [{
        "system" : "http://dips.no/fhir/R4/CodeSystem/NoImplQSOFAcomponentCodes",
        "code" : "QsofaResRate",
        "display" : "QsofaResRate"
      }]
    },
    "valueQuantity" : {
      "value" : 1,
      "unit" : "ScoreOf",
      "system" : "http://unitsofmeasure.org",
      "code" : "{ScoreOf}"
    },
    "interpretation" : [{
      "text" : "≥22"
    }]
  },
  {
    "code" : {
      "coding" : [{
        "system" : "http://dips.no/fhir/R4/CodeSystem/NoImplQSOFAcomponentCodes",
        "code" : "QsofaSystolicBP",
        "display" : "QsofaSystolicBP"
      }]
    },
    "valueQuantity" : {
      "value" : 1,
      "unit" : "ScoreOf",
      "system" : "http://unitsofmeasure.org",
      "code" : "{ScoreOf}"
    },
    "interpretation" : [{
      "text" : "≤100"
    }]
  },
  {
    "code" : {
      "coding" : [{
        "system" : "http://dips.no/fhir/R4/CodeSystem/NoImplQSOFAcomponentCodes",
        "code" : "QsofaMentalStatus",
        "display" : "QsofaMentalStatus"
      }]
    },
    "valueQuantity" : {
      "value" : 1,
      "unit" : "ScoreOf",
      "system" : "http://unitsofmeasure.org",
      "code" : "{ScoreOf}"
    },
    "interpretation" : [{
      "text" : "Endret mental status"
    }]
  }]
}

```
