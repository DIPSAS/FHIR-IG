# DIPSRelatedPersonParentalResponsibility - DIPS Core Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **DIPSRelatedPersonParentalResponsibility**

## Extension: DIPSRelatedPersonParentalResponsibility 

| | |
| :--- | :--- |
| *Official URL*:http://dips.no/fhir/StructureDefinition/R4/DIPSRelatedPersonParentalResponsibility | *Version*:0.1.0 |
| Draft as of 2026-11-05 | *Computable Name*:DIPSRelatedPersonParentalResponsibility |

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [DIPSRelatedPerson](StructureDefinition-DIPSRelatedPerson.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/dips.fhir.no.core|current/StructureDefinition/StructureDefinition-DIPSRelatedPersonParentalResponsibility.json)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-DIPSRelatedPersonParentalResponsibility.csv), [Excel](StructureDefinition-DIPSRelatedPersonParentalResponsibility.xlsx), [Schematron](StructureDefinition-DIPSRelatedPersonParentalResponsibility.sch) 

#### Constraints



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "DIPSRelatedPersonParentalResponsibility",
  "url" : "http://dips.no/fhir/StructureDefinition/R4/DIPSRelatedPersonParentalResponsibility",
  "version" : "0.1.0",
  "name" : "DIPSRelatedPersonParentalResponsibility",
  "status" : "draft",
  "date" : "2026-11-05T07:34:57+00:00",
  "publisher" : "DIPS AS",
  "contact" : [{
    "name" : "Lars-Andreas Nystad",
    "telecom" : [{
      "system" : "email",
      "value" : "mailto:lan@dips.no",
      "use" : "work"
    }]
  }],
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "NO",
      "display" : "Norway"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  }],
  "kind" : "complex-type",
  "abstract" : false,
  "context" : [{
    "type" : "element",
    "expression" : "RelatedPerson"
  }],
  "type" : "Extension",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Extension",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Extension.extension",
      "path" : "Extension.extension",
      "max" : "0"
    },
    {
      "id" : "Extension.url",
      "path" : "Extension.url",
      "fixedUri" : "http://dips.no/fhir/StructureDefinition/R4/DIPSRelatedPersonParentalResponsibility"
    },
    {
      "id" : "Extension.value[x]",
      "path" : "Extension.value[x]",
      "type" : [{
        "code" : "boolean"
      }]
    }]
  }
}

```
