# PractionerRole details of agb91 - DIPS Core Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **PractionerRole details of agb91**

## Example PractitionerRole: PractionerRole details of agb91

(no practitioner) (urn:oid:1.3.6.1.4.1.9038.51.1#91)

-------



## Resource Content

```json
{
  "resourceType" : "PractitionerRole",
  "id" : "agb91",
  "identifier" : [{
    "system" : "urn:oid:1.3.6.1.4.1.9038.51.1",
    "value" : "91"
  }]
}

```
